/**
  ******************************************************************************
  * @file    bsp_can.c
  * @author  AresZzz��ֲ
  * @version V1.0
  * @date    2016/12/26
  * @brief   
  * 
  ******************************************************************************
  * @attention
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "task_init.h"
/* Defines -------------------------------------------------------------------*/
extern int wave[4];
/* Variables -----------------------------------------------------------------*/
uint16_t FPS_Mboard=0;
//MBOARD Mboard={0};//����
_MBOARD MainBoard={0};
int16_t encoder_temp;
int16_t  encoder_num_this;
int32_t encoder_num;
int16_t	encoder_num_last;
int8_t first_flag;
int8_t bullet_flag_r=0;
extern int Fc_Speed[2];

extern int8_t fc_flag;
extern int16_t Bullet_cnt;
extern int8_t cs_flag;
/* Function  -----------------------------------------------------------------*/
/**
  * @brief  ��can.c��HAL_CAN_MspInit�е��ã�can���˲���������
  * @param  CAN_HandleTypeDef* hcan
  * @retval None
  */
void My_CAN1_FilterConfig(CAN_HandleTypeDef* _hcan)
{
	CAN_FilterConfTypeDef		CAN_FilterConfigStructure;
	static CanTxMsgTypeDef		TxMessage;
  static CanRxMsgTypeDef 		RxMessage;
	
	CAN_FilterConfigStructure.FilterNumber = 0;
	CAN_FilterConfigStructure.FilterMode = CAN_FILTERMODE_IDMASK;
	CAN_FilterConfigStructure.FilterScale = CAN_FILTERSCALE_32BIT;
	CAN_FilterConfigStructure.FilterIdHigh = 0x0000;
	//CAN_FilterConfigStructure.FilterIdHigh= (((uint32_t)(CAN_MAIN_CONTROL_RECEIVE_ID)<<21)&0xFFFF0000)>>16;
	CAN_FilterConfigStructure.FilterIdLow = 0x0000;
	//CAN_FilterConfigStructure.FilterMaskIdHigh = 0xFFE0;//1111 1111 1110 0000
	CAN_FilterConfigStructure.FilterMaskIdHigh = 0x0000;
	CAN_FilterConfigStructure.FilterMaskIdLow = 0x0000;
	CAN_FilterConfigStructure.FilterFIFOAssignment = CAN_FilterFIFO0;
	CAN_FilterConfigStructure.BankNumber = 14;
	CAN_FilterConfigStructure.FilterActivation = ENABLE;
	
	//��ʼ�����ɹ�������ѭ����̫�ã���Ȼ����һ�㲻����ʲô���⣩
	if(HAL_CAN_ConfigFilter(_hcan, &CAN_FilterConfigStructure) != HAL_OK)
	{
		while(1);
	}

	_hcan->pTxMsg = &TxMessage;
	_hcan->pRxMsg = &RxMessage;
}
void My_CAN2_FilterConfig(CAN_HandleTypeDef* _hcan)
{
	CAN_FilterConfTypeDef		CAN_FilterConfigStructure;
	static CanTxMsgTypeDef		TxMessage;
  static CanRxMsgTypeDef 		RxMessage;
	
	CAN_FilterConfigStructure.FilterNumber = 14;
	CAN_FilterConfigStructure.FilterMode = CAN_FILTERMODE_IDMASK;
	CAN_FilterConfigStructure.FilterScale = CAN_FILTERSCALE_32BIT;
	CAN_FilterConfigStructure.FilterIdHigh = 0x0000;
	//CAN_FilterConfigStructure.FilterIdHigh= (((uint32_t)(CAN_MAIN_CONTROL_RECEIVE_ID)<<21)&0xFFFF0000)>>16;
	CAN_FilterConfigStructure.FilterIdLow = 0x0000;
	//CAN_FilterConfigStructure.FilterMaskIdHigh = 0xFFE0;//1111 1111 1110 0000
	CAN_FilterConfigStructure.FilterMaskIdHigh = 0x0000;
	CAN_FilterConfigStructure.FilterMaskIdLow = 0x0000;
	CAN_FilterConfigStructure.FilterFIFOAssignment = CAN_FilterFIFO0;
	CAN_FilterConfigStructure.BankNumber = 14;
	CAN_FilterConfigStructure.FilterActivation = ENABLE;
	
	//��ʼ�����ɹ�������ѭ����̫�ã���Ȼ����һ�㲻����ʲô���⣩
	if(HAL_CAN_ConfigFilter(_hcan, &CAN_FilterConfigStructure) != HAL_OK)
	{
		while(1);
	}

	_hcan->pTxMsg = &TxMessage;
	_hcan->pRxMsg = &RxMessage;
}

 
int32_t temp_dipan_gyro = 0;
extern float ptz_yaw_angle_error;
/**
  * @brief  CAN�жϵĻص�����
  * @param  CAN_HandleTypeDef* _hcan
  * @retval None
  */
int16_t error;
void HAL_CAN_RxCpltCallback(CAN_HandleTypeDef* _hcan)
{
	static uint32_t  bullet_timer=0;
	int timer_n;
//	static int8_t first_flag1=0;
	HAL_IWDG_Refresh(&hiwdg);
	
  if(_hcan == &hcan2)
  {
		frame.CAN2_Mboard.Present++;
		switch(_hcan->pRxMsg->StdId)
		{
			case BOARD_CONTROL:
				//FPS_Mboard++;
				//Mboard.yaw				=(int16_t)(_hcan->pRxMsg->Data[0]<<8)|(int16_t)(_hcan->pRxMsg->Data[1]);
			  MainBoard.Yaw     =(int16_t)(_hcan->pRxMsg->Data[0]<<8)|(int16_t)(_hcan->pRxMsg->Data[1]);
				//Mboard.pitch			=(int16_t)(_hcan->pRxMsg->Data[2]<<8)|(int16_t)(_hcan->pRxMsg->Data[3]);
			  MainBoard.Pitch		=(int16_t)(_hcan->pRxMsg->Data[2]<<8)|(int16_t)(_hcan->pRxMsg->Data[3]);
				//Mboard.flag_shoot		=_hcan->pRxMsg->Data[4];
			  MainBoard.Frictiongear_Flag=_hcan->pRxMsg->Data[4];
			
				//Mboard.flag_door_open	=_hcan->pRxMsg->Data[5];
			  MainBoard.Shoot_Flag  =_hcan->pRxMsg->Data[5];
			  
				//Mboard.flag_mode  		=_hcan->pRxMsg->Data[6];
			  MainBoard.Cartridge   =_hcan->pRxMsg->Data[6];
			//	Mboard.flag_wheel_run	=_hcan->pRxMsg->Data[7];
			  MainBoard.Level=_hcan->pRxMsg->Data[7];
			break;
			
			case JUGEMENT_ID:
			//MainBoard.Heat_Back=(uint16_t)(_hcan->pRxMsg->Data[0]<<8 |_hcan->pRxMsg->Data[1]);
		//	MainBoard.Bullet_Speed=(float) (_hcan->pRxMsg->Data[4]<<24|_hcan->pRxMsg->Data[5]<<16|\
																			_hcan->pRxMsg->Data[6]<<8|_hcan->pRxMsg->Data[7]);
			memcpy(&MainBoard.Heat_Back,&_hcan->pRxMsg->Data[0],sizeof(uint16_t));
			memcpy(&MainBoard.Bullet_Speed,&_hcan->pRxMsg->Data[4],sizeof(float));
			
			break;
			case BOARD_CONTROL2:
				MainBoard.Shoot_Mode=_hcan->pRxMsg->Data[0];
			  MainBoard.Flag_Mode=_hcan->pRxMsg->Data[1];
			  MainBoard.Defend_Flag=_hcan->pRxMsg->Data[2];
			  MainBoard.JugeMent_Confirm=_hcan->pRxMsg->Data[3];
			  MainBoard.Control_Flag=_hcan->pRxMsg->Data[4];
			  MainBoard.Speed_Control=_hcan->pRxMsg->Data[5];
			  Pc_Data.BaoGuang=_hcan->pRxMsg->Data[6];
			  MainBoard.Blood_Flag=_hcan->pRxMsg->Data[7];
				break;
				
			default: break;
		}
		
		
  }
	if(_hcan == &hcan1)
  {
     if(_hcan->pRxMsg->StdId == PITCH_ID)     //pitch
     {
			frame.CAN1_Pitch.Present++;
			motor.pitch.present.current=(_hcan->pRxMsg->Data[2]<<8)|(_hcan->pRxMsg->Data[3]);
			motor.pitch.present.angle_pre=(_hcan->pRxMsg->Data[0]<<8)|(_hcan->pRxMsg->Data[1]);;
      #if (PAN_JOIN_FIND==0) 			
			if(motor.pitch.present.angle_pre>PITCH_MOTOR_TRIG) motor.pitch.present.angle_pre-=8191;
		  #if (PAN_MOTOR_ZERO_FIND==0)//��̨���������
			motor.pitch.present.angle	=(PITCH_REF_ANGLE-motor.pitch.present.angle_pre);
			motor.pitch.present.angle_t=motor.pitch.present.angle*(float)0.0439506776;
		  #endif
      #endif
	  }
    if(_hcan->pRxMsg->StdId == YAW_ID)     //yaw 
    {
			frame.CAN1_Yaw.Present++;
			motor.yaw.present.current=(_hcan->pRxMsg->Data[2]<<8)|(_hcan->pRxMsg->Data[3]);
			motor.yaw.present.angle_pre=(_hcan->pRxMsg->Data[0]<<8)|(_hcan->pRxMsg->Data[1]);;
      #if (PAN_JOIN_FIND==0) 
			#ifdef Ares
			  if(motor.yaw.present.angle_pre<YAW_MOTOR_TRIG) motor.yaw.present.angle_pre+=8191;
			#endif
			#ifdef Azrael
			  if(motor.yaw.present.angle_pre>YAW_MOTOR_TRIG) motor.yaw.present.angle_pre-=8191;
			#endif
			#ifdef BigHead
			  if(motor.yaw.present.angle_pre<YAW_MOTOR_TRIG) motor.yaw.present.angle_pre+=8191;
			#endif
		    #if (PAN_MOTOR_ZERO_FIND==0)//��̨���������	
			     motor.yaw.present.angle=(YAW_REF_ANGLE - motor.yaw.present.angle_pre);
					 motor.yaw.present.angle_t=motor.yaw.present.angle*(float)0.0439506776;

		    #endif
      #endif	
   }
	 if(_hcan->pRxMsg->StdId == 0x201)//MocalunA
	 {
		  frame.CAN1_Wheel_Left.Present++;
			wheel[WHE_RIGHT].speed_present	=(_hcan->pRxMsg->Data[2]<<8) | _hcan->pRxMsg->Data[3];
		  wave[0]=wheel[WHE_RIGHT].speed_present+Fc_Speed[MainBoard.Speed_Control];
		 //����Ƿ��
		 if(MainBoard.Speed_Control==0)
		 {
			 if(wheel[WHE_RIGHT].speed_present-wheel[WHE_RIGHT].speed_target>=230)
			 {
					if(fc_flag==1&& cs_flag==1)
					{
						timer_n=timer_cnt-bullet_timer;
						if(timer_n>70)
						{
							Bullet_cnt++;
						  bullet_timer=timer_cnt;
						}
					}	
			  }
		 }
		 else if(MainBoard.Speed_Control==1)
		 {
			 if(wheel[WHE_RIGHT].speed_present-wheel[WHE_RIGHT].speed_target>=150)
			 {
					if(fc_flag==1&& cs_flag==1)
					{
						timer_n=timer_cnt-bullet_timer;
						if(timer_n>50)
						{
							Bullet_cnt++;
						  bullet_timer=timer_cnt;
						}
					}	
			  }
		 }
		 
	 }
	 if(_hcan->pRxMsg->StdId == 0x202)//MocalunB
	 {
		 frame.CAN1_Wheel_Right.Present++;
		 wheel[WHE_LEFT].speed_present	=(_hcan->pRxMsg->Data[2]<<8) | _hcan->pRxMsg->Data[3];
		 wave[1]=wheel[WHE_LEFT].speed_present-Fc_Speed[MainBoard.Speed_Control];
	 }	
	 if(_hcan->pRxMsg->StdId==0x203)//MocalunC
	 {
		  frame.CAN1_Wheel_Dial.Present++;
		  wheel[WHE_DIAL].speed_present=(_hcan->pRxMsg->Data[2]<<8) | _hcan->pRxMsg->Data[3];
			wheel[WHE_DIAL].angle_present	=(_hcan->pRxMsg->Data[0]<<8) | _hcan->pRxMsg->Data[1];
			encoder_num_this=	wheel[WHE_DIAL].angle_present;
			wheel[WHE_DIAL].speed_present=0.1*wheel[WHE_DIAL].speed_present;
			if(!first_flag) 
				{
					encoder_num_last=24573;
					first_flag++;
				}
	    encoder_temp=encoder_num_this-encoder_num_last;
			encoder_num+=encoder_temp;
	//�����ֵ�ж�
    	if((encoder_temp) > 4500) 
	  	encoder_num -= 8191;
	    else if((encoder_temp) < -4500) 
		  encoder_num += 8191;

			if(encoder_num>294876) encoder_num=encoder_num-294876;
			if(encoder_num<0) encoder_num=encoder_num+294876;
			wheel[WHE_DIAL].angle_present=encoder_num*0.001220852154; //ת��Ϊ�����������ĽǶ�
	//��һ��λ��
	    encoder_num_last=encoder_num_this;
		}
  }
	
	__HAL_CAN_ENABLE_IT(_hcan, CAN_IT_FMP0);
}


//���͸�����
void PanTiltToBoard(CAN_Message_ID Motor_ID,float DATA_1,int16_t DATA_2)
{
    
    uint8_t send_data[8]={0};
    memcpy(&send_data[0],&DATA_1,sizeof(float));
		send_data[4] = (unsigned char)(DATA_2 >> 8);;
		send_data[5] = (unsigned char)DATA_2 ;
		SendMessageToCANQueue(2,Motor_ID, send_data);
}


/**
  * @brief  ����can����Ϣ
  * @param  CAN_HandleTypeDef* _hcan
  * @param  CAN_Message_ID _id
  * @param	int16_t* _message3
  * @param	uint8_t* _pBuff
  * @retval None
  */
HAL_StatusTypeDef CAN_Send_Message(CAN_HandleTypeDef* _hcan, CAN_Message_ID _id, uint8_t* _message)
{
 
  HAL_StatusTypeDef halStatus;
	
  _hcan->pTxMsg->RTR = CAN_RTR_DATA;
  _hcan->pTxMsg->IDE = CAN_ID_STD;
  _hcan->pTxMsg->StdId = _id;

	_hcan->pTxMsg->DLC = 8;
  memcpy(&_hcan->pTxMsg->Data[0],_message,8);
	//ʱ�䲻��̫С����Ȼ��timeout
	halStatus = HAL_CAN_Transmit(_hcan, 0x24);
  
  return(halStatus);
}
