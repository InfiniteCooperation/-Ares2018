#ifndef _BSP_FIRCTIONGEAR_H_
#define _BSP_FIRCTIONGEAR_H_

#include <stm32f4xx.h>
#include "bsp_ptz_control.h"

//����
#define LASER_OFF()       HAL_GPIO_WritePin(GPIOC, GPIO_PIN_10, GPIO_PIN_RESET)
#define LASER_ON()        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_10, GPIO_PIN_SET)
//typedef enum {LEFT=0, RIGHT=1, MIDDLE=2} whell;
#define WHE_LEFT 	0 //Ħ���ֱ��
#define WHE_RIGHT 	1
#define WHE_DIAL	2
#define WHE_MIDDLE	3

#ifdef Azrael
#define CARTRIDGE_OPEN  200
#define CARTRIDGE_CLOSE 76
#endif

#ifdef BigHead
#define CARTRIDGE_OPEN  220
#define CARTRIDGE_CLOSE 100
#endif

#ifdef Ares
#define CARTRIDGE_OPEN  200
#define CARTRIDGE_CLOSE 103
#endif
/*** ս��Ħ����PWM�趨 ******************************/

typedef struct 
{	
	float k_p;
	float k_i;
	float k_d;
	_PID position;
	_PID velocity;
	int16_t error[3];
	int16_t speed_present;
	int16_t angle_present;
	int16_t angle_target;
	int16_t speed_target;

	int16_t output;

}_WHEEL;


extern _WHEEL wheel[4];
extern uint8_t open_run_side,open_run_mid;
extern _WHEEL dial;
extern void Wheel_Param_Init(void);
extern uint8_t Shoot_Detection(void);
extern void frictiongear_Control(void);
float Dial_Increment_Control(_WHEEL *whe); //�ٶ� ����
float Dial_Position_Control(_WHEEL *whe);  //λ�ÿ���
void Cartridge_Control(void);
void Wheel_Sent(CAN_Message_ID Motor_ID,int16_t Wheel_A,int16_t Wheel_B,int16_t Dial,int16_t Wheel_D);
#endif
