/**
  ******************************************************************************
  * @file    task_ptz_control.c
  * @author  AresZzz ��ֲ
  * @version V1.0
  * @date    2018/04/17
  * @brief   ��̨����
  * 
  ******************************************************************************
  * @attention
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "task_init.h"
/* Defines -------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/***MPU6050 DMP��********************************/
float q0=0.0f,q1=0.0f,q2=0.0f,q3=0.0f;
long quat[4];		//dmp��ȡʱ��ŵ���Ԫ������
unsigned char more;
unsigned long sensor_timestamp;
short gyro[3], accel[3], sensors;
int wave[4];
	//�����ת��
uint8_t flag_over_current=0;
float can1_send_motor_mid_value;
//�����Ƕȴ�����
float d_pitch,d_yaw;
volatile uint16_t v_pitch,v_yaw;

MOTOR motor={0};
MPU6050 mpu={0};//mpu6050

SET_MSG_PTZ MessageToPTZMotor;

float error_pitch,error_yaw;
volatile uint16_t v_pitch,v_yaw;

float angle;
int16_t angle2;

//float LIMIT_L,LIMIT_R;
uint8_t Dema_Flag=0;

uint8_t All_Complite=0;

extern uint8_t Fire_Bullet;
extern uint32_t PcClear_Timer;

int16_t flag_shoot_back;
uint16_t Bullet_Sent=0;
/* Function  -----------------------------------------------------------------*/
/**************************************************************************
*@date  2016-11-19 10:57:55
*@brief ������ʼ��
*
**************************************************************************/

void Pan_Param_Init(void)
{
#if defined(Azrael)
	
	motor.pitch.position.kp=310;//��̨���pitchλ�û�����
	motor.pitch.position.ki=1;
	motor.pitch.position.kd=30;   	
	motor.pitch.velocity.kp=2.5;//��̨���pitch�ٶȻ�����
	motor.pitch.velocity.ki=0;
	motor.pitch.velocity.kd=0.5;
	

	motor.yaw.position.kp=280;
	motor.yaw.position.ki=1;
	motor.yaw.position.kd=35;
	
	motor.yaw.velocity.kp=4;
	motor.yaw.velocity.ki=0;
	motor.yaw.velocity.kd=0.5;
	
/***********************************/	
	mpu.pitch.position.kp=200;//
	mpu.pitch.position.ki=0.1;//
	mpu.pitch.position.kd=30;//
	
	mpu.pitch.velocity.kp=2.5;//
	mpu.pitch.velocity.ki=0;
	mpu.pitch.velocity.kd=1.5;
	
	
	mpu.yaw.position.kp=300;
	mpu.yaw.position.ki=0.1;
	mpu.yaw.position.kd=60;
	
	mpu.yaw.assint_pos.kp=37;
	mpu.yaw.assint_pos.ki=0;
	mpu.yaw.assint_pos.kd=0;
	
	
	mpu.yaw.velocity.kp=3;
	mpu.yaw.velocity.ki=0;
	mpu.yaw.velocity.kd=2;
	
	mpu.yaw.assint_vel.kp=81;
	mpu.yaw.assint_vel.ki=0;
	mpu.yaw.assint_vel.kd=249;
#endif

#if defined(BigHead)
	
	motor.pitch.position.kp=320;//��̨���pitchλ�û�����
	motor.pitch.position.ki=3;
	motor.pitch.position.kd=40;
	
	motor.pitch.velocity.kp=2;//��̨���pitch�ٶȻ�����
	motor.pitch.velocity.ki=0;
	motor.pitch.velocity.kd=0.5;
	
	motor.yaw.position.kp=280;
	motor.yaw.position.ki=1;
	motor.yaw.position.kd=30;
	
	motor.yaw.velocity.kp=6;
	motor.yaw.velocity.ki=0;
	motor.yaw.velocity.kd=0.5;
/***********************************/	
	mpu.pitch.position.kp=200;//
	mpu.pitch.position.ki=0.1;//
	mpu.pitch.position.kd=30;//
	
	mpu.pitch.velocity.kp=2;//
	mpu.pitch.velocity.ki=0;
	mpu.pitch.velocity.kd=1.5;
	
	
	mpu.yaw.position.kp=280;
	mpu.yaw.position.ki=0.1;
	mpu.yaw.position.kd=60;
	
	mpu.yaw.velocity.kp=3;
	mpu.yaw.velocity.ki=0;
	mpu.yaw.velocity.kd=3;
	
	mpu.yaw.assint_pos.kp=37;
	mpu.yaw.assint_pos.ki=0;
	mpu.yaw.assint_pos.kd=0;
	mpu.yaw.assint_vel.kp=84;
	mpu.yaw.assint_vel.ki=0;
	mpu.yaw.assint_vel.kd=237;
	
#endif
#if defined(Ares)
	
	motor.pitch.position.kp=260;//��̨���pitchλ�û�����
	motor.pitch.position.ki=1;
	motor.pitch.position.kd=30;   	
	motor.pitch.velocity.kp=3;//��̨���pitch�ٶȻ�����
	motor.pitch.velocity.ki=0;
	motor.pitch.velocity.kd=0.5;
	
	
	
	
	motor.yaw.position.kp=280;
	motor.yaw.position.ki=1;
	motor.yaw.position.kd=40;
	
	motor.yaw.velocity.kp=5;
	motor.yaw.velocity.ki=0;
	motor.yaw.velocity.kd=0.5;
/***********************************/	
	mpu.pitch.position.kp=200;//
	mpu.pitch.position.ki=0.1;//
	mpu.pitch.position.kd=30;//
	
	mpu.pitch.velocity.kp=2;//
	mpu.pitch.velocity.ki=0;
	mpu.pitch.velocity.kd=1.5;
	
	
	mpu.yaw.position.kp=260;
	mpu.yaw.position.ki=0.1;
	mpu.yaw.position.kd=60;
	
	mpu.yaw.velocity.kp=3;
	mpu.yaw.velocity.ki=0;
	mpu.yaw.velocity.kd=2;
	
	mpu.yaw.assint_pos.kp=37;
	mpu.yaw.assint_pos.ki=0;
	mpu.yaw.assint_pos.kd=0;
	mpu.yaw.assint_vel.kp=81;
	mpu.yaw.assint_vel.ki=0;
	mpu.yaw.assint_vel.kd=249;
#endif
}
/********************************************************************************
*@date	 2016-11-20 16:20:47
*@brief  pitch�����
*@input  ��̨�����Ϣ
*@outupt ��̨���pitch���ٶȻ����������ֵ��ֱ�Ӹ������
*@ARES
*********************************************************************************/
float Motor_Pitch_Control(MOTOR *motor)
{
/********************λ�ã��Ƕȣ���*********************************************/
	//��pitch��е�Ƕȣ�0~8191������ɱ�׼�Ƕȣ�0~360�ȣ�//����ƫ��
	motor->pitch.position.error[0] = motor->pitch.target.angle - motor->pitch.present.angle_t; 
	//2017-4-19 07:17:20 ʵ�飺������ԽǶȼ���
//	motor->pitch.position.error[0] = motor->pitch.target.angle - motor->pitch.present.angle; 
	motor->pitch.position.increment+=  motor->pitch.position.error[0];//����
	if(motor->pitch.position.increment>3000)//�����޷�  
		motor->pitch.position.increment=3000;
	else if(motor->pitch.position.increment<-3000)
			motor->pitch.position.increment=-3000;
	motor->pitch.position.pid_out =  motor->pitch.position.kp * motor->pitch.position.error[0]\
								   + motor->pitch.position.ki * motor->pitch.position.increment\
								   + motor->pitch.position.kd * (gyro[1])* (3.14159265/180.0);
	if(motor->pitch.position.pid_out > CURRENT_MAX)
		motor->pitch.position.pid_out = CURRENT_MAX;
	else if(motor->pitch.position.pid_out < -CURRENT_MAX)
		motor->pitch.position.pid_out = -CURRENT_MAX;
/*****************�ٶȻ�*******************************************************/
    motor->pitch.velocity.error[1] = motor->pitch.velocity.error[0];//����ƫ��
	
    motor->pitch.velocity.error[0] = motor->pitch.position.pid_out - (-gyro[1]*(3.14159265/180.0));//�����ٶȻ�ƫ��
	
    motor->pitch.velocity.pid_out =	 motor->pitch.velocity.kp * motor->pitch.velocity.error[0]\
								   + motor->pitch.velocity.kd * (motor->pitch.velocity.error[0] - motor->pitch.velocity.error[1]);

		if(motor->pitch.velocity.pid_out > CURRENT_MAX)//����޷�
			motor->pitch.velocity.pid_out = CURRENT_MAX;
		else if(motor->pitch.velocity.pid_out < -CURRENT_MAX)
			motor->pitch.velocity.pid_out = -CURRENT_MAX;	
	
    return motor->pitch.velocity.pid_out;
}

/********************************************************************************
*@date	 2017-2-27 14:48:19
*@brief  yaw�����
*@input  ��̨�����Ϣ
*@outupt ��̨���yaw���ٶȻ����������ֵ��ֱ�Ӹ������
*@ARES
*********************************************************************************/
float Motor_Yaw_Control(MOTOR *motor)
{
/********* λ�ã��Ƕȣ��� *****************/
	motor->yaw.position.error[0] = motor->yaw.target.angle - motor->yaw.present.angle_t;//˳ʱ��תʱ������error < 0�����
		
	motor->yaw.position.increment +=  motor->yaw.position.error[0];//����粻ͬ
	
	if(motor->yaw.position.increment>3000)//�����޷� 
		motor->yaw.position.increment=3000;
	else if(motor->yaw.position.increment<-3000)
		motor->yaw.position.increment=-3000;

	motor->yaw.position.pid_out =  motor->yaw.position.kp * motor->yaw.position.error[0]\
								 + motor->yaw.position.ki * motor->yaw.position.increment\
								 + motor->yaw.position.kd * (gyro[2])* (3.14159265/180.0);//�ҳ�yaw��Ӧ�ĽǼ��ٶȣ�����

	if(motor->yaw.position.pid_out > CURRENT_MAX)
		motor->yaw.position.pid_out = CURRENT_MAX;
	else if(motor->yaw.position.pid_out < -CURRENT_MAX)
		motor->yaw.position.pid_out = -CURRENT_MAX;
		
/********* �ٶȻ� *********************************************************/
  motor->yaw.velocity.error[1] = motor->yaw.velocity.error[0];//����ƫ��
	
  motor->yaw.velocity.error[0] = motor->yaw.position.pid_out - (-gyro[2]*(3.14159265/180.0));//�����ٶȻ�ƫ�� //�ҳ�yaw��Ӧ�ĽǼ��ٶ�
	
  motor->yaw.velocity.pid_out =	  motor->yaw.velocity.kp * motor->yaw.velocity.error[0]\
								+ motor->yaw.velocity.kd *(motor->yaw.velocity.error[0] - motor->yaw.velocity.error[1]);

	if(motor->yaw.velocity.pid_out > CURRENT_MAX)//����޷�
		motor->yaw.velocity.pid_out = CURRENT_MAX;
	else if(motor->yaw.velocity.pid_out < -CURRENT_MAX)
		motor->yaw.velocity.pid_out = -CURRENT_MAX;		

	return motor->yaw.velocity.pid_out;	
}

/**************************************************************************
*@date  2016-11-20 01:09:54
*@brief MPU6050 pitch �ռ䱣�ֿ���
*@input mpu6050��Ϣ
*@ARES
*@note	��Ҫע�� ��mpu pitchƫ����ţ� �� ����̨���ת������ �Ĺ�ϵ
**************************************************************************/
float MPU_Pitch_Control(MPU6050 *mpu)
{
/*
  ��Ҫ��취�������ֵ�ķ�Χ������̨�˶����ܳ����䷶Χ--->
*/
/*********λ�ã��Ƕȣ���** Ҫע�����̨pitch���Ӧ����mpu�ĸ���  pitch��Ӧ y�� ��gyro[0]***************/
	mpu->pitch.position.error[0] = mpu->pitch.target.angle - mpu->pitch.present.angle;
	
	mpu->pitch.position.increment +=  mpu->pitch.position.error[0];//��ͬ
	
	if(mpu->pitch.position.increment>3000)//�����޷� 
		mpu->pitch.position.increment=3000;
	else if(mpu->pitch.position.increment<-3000)
		mpu->pitch.position.increment=-3000;
	mpu->pitch.position.pid_out =  mpu->pitch.position.kp * mpu->pitch.position.error[0]\
								 + mpu->pitch.position.ki * mpu->pitch.position.increment\
								 + mpu->pitch.position.kd * (gyro[1])* (3.14159265/180.0);

	if(mpu->pitch.position.pid_out > CURRENT_MAX)
		mpu->pitch.position.pid_out = CURRENT_MAX;
	else if(mpu->pitch.position.pid_out < -CURRENT_MAX)
		mpu->pitch.position.pid_out = -CURRENT_MAX;
		
/*********�ٶȻ�*** Ҫע�����̨pitch���Ӧ����mpu�ĸ��� *********************/
    mpu->pitch.velocity.error[1] = mpu->pitch.velocity.error[0];//����ƫ��
	
    mpu->pitch.velocity.error[0] = mpu->pitch.position.pid_out - (-gyro[1]*(3.14159265/180.0));//�����ٶȻ�ƫ��
	
    mpu->pitch.velocity.pid_out =	 mpu->pitch.velocity.kp*mpu->pitch.velocity.error[0]\
								   + mpu->pitch.velocity.kd*(mpu->pitch.velocity.error[0] - mpu->pitch.velocity.error[1]);

    if(mpu->pitch.velocity.pid_out > CURRENT_MAX)//����޷�
      mpu->pitch.velocity.pid_out = CURRENT_MAX;
    else if(mpu->pitch.velocity.pid_out < -CURRENT_MAX)
			mpu->pitch.velocity.pid_out = -CURRENT_MAX;
	return mpu->pitch.velocity.pid_out;
}

/**************************************************************************
*@date  
*@brief 
*@input 
*@ARES
*@note	mpu yaw �� ����; motor �� ������������ ���� �Ҹ�
*		���ת�� ���� ���� 
*       ��yaw 360����ת�������-180��180֮�����Ծ����Ҫ����
**************************************************************************/
float MPU_Yaw_Control(MPU6050 *mpu)
{
/********* λ�ã��Ƕȣ��� *****************/
	if((mpu->yaw.target.angle - mpu->yaw.present.angle) > 180.0f //����a-(-b)>180 �� -a-b<-180�����
	   || (mpu->yaw.target.angle - mpu->yaw.present.angle) < -180.0f )
	{
		if( mpu->yaw.target.angle > 0 && mpu->yaw.present.angle < 0 ) 	
			mpu->yaw.position.error[0] =( -180.0f - mpu->yaw.present.angle) + ( mpu->yaw.target.angle - 180.0f );
		
		if( mpu->yaw.target.angle < 0 && mpu->yaw.present.angle > 0 )
			mpu->yaw.position.error[0] =( 180.0f - mpu->yaw.present.angle) + ( mpu->yaw.target.angle + 180.0f );
	}
	else
		mpu->yaw.position.error[0] = mpu->yaw.target.angle - mpu->yaw.present.angle;//˳ʱ��תʱ������error < 0�����
	
	mpu->yaw.position.increment +=  mpu->yaw.position.error[0];//����粻ͬ
	if(mpu->yaw.position.increment>1000)//�����޷� 
		mpu->yaw.position.increment=1000;
	else if(mpu->yaw.position.increment<-1000)
			mpu->yaw.position.increment=-1000;
	mpu->yaw.position.pid_out =    mpu->yaw.position.kp * mpu->yaw.position.error[0]\
								 + mpu->yaw.position.ki * mpu->yaw.position.increment\
								 + mpu->yaw.position.kd * (gyro[2])* (3.14159265/180.0);//�ҳ�yaw��Ӧ�ĽǼ��ٶȣ�����

	if(mpu->yaw.position.pid_out > CURRENT_MAX)
		mpu->yaw.position.pid_out = CURRENT_MAX;
	else if(mpu->yaw.position.pid_out < -CURRENT_MAX)
		mpu->yaw.position.pid_out = -CURRENT_MAX;
		
/********* �ٶȻ� *********************************************************/
  mpu->yaw.velocity.error[1] = mpu->yaw.velocity.error[0];//����ƫ��
	
  mpu->yaw.velocity.error[0] = mpu->yaw.position.pid_out - (-gyro[2]*(3.14159265/180.0));//�����ٶȻ�ƫ�� //�ҳ�yaw��Ӧ�ĽǼ��ٶ�
	
  mpu->yaw.velocity.pid_out =	  mpu->yaw.velocity.kp * mpu->yaw.velocity.error[0]\
								+ mpu->yaw.velocity.kd *(mpu->yaw.velocity.error[0] - mpu->yaw.velocity.error[1]);

  if(mpu->yaw.velocity.pid_out > CURRENT_MAX)//����޷�
     mpu->yaw.velocity.pid_out = CURRENT_MAX;
  else if(mpu->yaw.velocity.pid_out < -CURRENT_MAX)
		mpu->yaw.velocity.pid_out = -CURRENT_MAX;
	return mpu->yaw.velocity.pid_out;
}

/**************************************************************************
*@date  
*@brief 
*@input 
*@ARES
*@note	mpu yaw �� ����; motor �� ������������ ���� �Ҹ�
*		���ת�� ���� ���� 
*       ��yaw 360����ת�������-180��180֮�����Ծ����Ҫ����
**************************************************************************/
float MPU_Yaw_Assist_Control(MPU6050 *mpu)
{
/********* λ�ã��Ƕȣ��� *****************/
	if((mpu->yaw.target.angle - mpu->yaw.present.angle) > 180.0f //����a-(-b)>180 �� -a-b<-180�����
	   || (mpu->yaw.target.angle - mpu->yaw.present.angle) < -180.0f )
	{
		if( mpu->yaw.target.angle > 0 && mpu->yaw.present.angle < 0 ) 	
			mpu->yaw.position.error[0] =( -180.0f - mpu->yaw.present.angle) + ( mpu->yaw.target.angle - 180.0f );
		
		if( mpu->yaw.target.angle < 0 && mpu->yaw.present.angle > 0 )
			mpu->yaw.position.error[0] =( 180.0f - mpu->yaw.present.angle) + ( mpu->yaw.target.angle + 180.0f );
	}
	else
		mpu->yaw.position.error[0] = mpu->yaw.target.angle - mpu->yaw.present.angle;//˳ʱ��תʱ������error < 0�����
	
	mpu->yaw.position.increment +=  mpu->yaw.position.error[0];//����粻ͬ
	if(mpu->yaw.position.increment>1000)//�����޷� 
		mpu->yaw.position.increment=1000;
	else if(mpu->yaw.position.increment<-1000)
			mpu->yaw.position.increment=-1000;
	mpu->yaw.position.pid_out =    mpu->yaw.assint_pos.kp * mpu->yaw.position.error[0]\
								 + mpu->yaw.assint_pos.ki * mpu->yaw.position.increment\
								 + mpu->yaw.assint_pos.kd * (gyro[2])* (3.14159265/180.0);//�ҳ�yaw��Ӧ�ĽǼ��ٶȣ�����

	if(mpu->yaw.position.pid_out > CURRENT_MAX)
		mpu->yaw.position.pid_out = CURRENT_MAX;
	else if(mpu->yaw.position.pid_out < -CURRENT_MAX)
		mpu->yaw.position.pid_out = -CURRENT_MAX;
		
/********* �ٶȻ� *********************************************************/
  mpu->yaw.velocity.error[1] = mpu->yaw.velocity.error[0];//����ƫ��
	
  mpu->yaw.velocity.error[0] = mpu->yaw.position.pid_out - (-gyro[2]*(3.14159265/180.0));//�����ٶȻ�ƫ�� //�ҳ�yaw��Ӧ�ĽǼ��ٶ�
	
  mpu->yaw.velocity.pid_out =	  mpu->yaw.assint_vel.kp * mpu->yaw.velocity.error[0]\
								+ mpu->yaw.assint_vel.kd *(mpu->yaw.velocity.error[0] - mpu->yaw.velocity.error[1]);

  if(mpu->yaw.velocity.pid_out > CURRENT_MAX)//����޷�
     mpu->yaw.velocity.pid_out = CURRENT_MAX;
  else if(mpu->yaw.velocity.pid_out < -CURRENT_MAX)
		mpu->yaw.velocity.pid_out = -CURRENT_MAX;
	return mpu->yaw.velocity.pid_out;
}

/**************************************************************************
*@date  2016-11-18 20:18:55
*@brief �������巢�͵���̨������Ϣ (����ת�������ȣ��޷�)
*@input 
*�����û�е��̨
*��������ͨģʽyaw���ÿռ���̨
**************************************************************************/
void Calculate_Target(void)
{
	float temp_yaw,temp_pitch,MotorAngleLimit;
	float temp_yaw_B,temp_pitch_B;
	static char Big_Flag=0;
	static char Yaw_Complite=0;
	static char Pitch_Complite=0;
//	static char Double_Complite=0;
	if(PcClear_Timer>200)
	{
		Pc_Data.yaw=0;
		Pc_Data.pitch=0;
	}

	switch (MainBoard.Flag_Mode) //ģʽѡ��
	{
 /*******  ��ͨģʽ *********/	
		case nomal_mode: //��ͨ
		Fire_Bullet=0;
		flag_shoot_back=Pc_Data.flag_shoot;
		temp_yaw 	= MainBoard.Yaw;
		temp_pitch 	= MainBoard.Pitch;
	
		if((temp_pitch>=-3)&&(temp_pitch<=3))	//pitch
			temp_pitch=0;
		motor.pitch.target.angle += temp_pitch/700;//700;	//���������ȣ�����ʽ��
		if(MainBoard.Control_Flag==0)
		{
			motor.yaw.target.angle=0;
		}
		else
		{
			if((temp_yaw>=-3)&&(temp_yaw<=3))	//yaw
			temp_yaw=0;
		  mpu.yaw.target.angle += temp_yaw/700;//700;	//���������ȣ�����ʽ��
		}
		
		if(Big_Flag==1)
		{
			motor.pitch.target.angle=0;
			Big_Flag=0;
		}
		break;
		 /*******  ���ģʽ *********/
		case rune_big_mode:
		case  rune_mode:  //���
		 temp_yaw=Pc_Data.yaw/100;
		 temp_pitch=-Pc_Data.pitch/100;
		
		 Big_Flag=1;
		//5.4��˫�������Ϳ��ƣ����ܵ��ǽǶ���Ϣ���������ٶ����ƣ���Ч��������
		if(temp_yaw-motor.yaw.target.angle>=2)
		{
			motor.yaw.target.angle+=(float)0.6;
			Yaw_Complite=0;
		}
		else if(temp_yaw-motor.yaw.target.angle<=-2)
		{
			motor.yaw.target.angle-=(float)0.6;
			Yaw_Complite=0;
		}
		else
		{
			motor.yaw.target.angle=temp_yaw;
			if(Pc_Data.flag_shoot!=flag_shoot_back && Pc_Data.flag_shoot!=0)
			{
				flag_shoot_back=Pc_Data.flag_shoot;
			  Yaw_Complite=1;
			}
		}
		
		if(temp_pitch-motor.pitch.target.angle>=1)
		{
			motor.pitch.target.angle+= (float)0.4;
			Pitch_Complite=0;
		}
		else if(temp_pitch-motor.pitch.target.angle<=-1)
		{
			motor.pitch.target.angle-=(float)0.4;
			Pitch_Complite=0;
		}
		else
		{
			motor.pitch.target.angle=temp_pitch;
			Pitch_Complite=1;
		}
		if(Yaw_Complite==1 && Pitch_Complite==1 && Fire_Bullet==0)
		{
			All_Complite=1;
			Yaw_Complite=0;
			Pitch_Complite=0;
		}
			break;                                                                                                                                         
		/*******  ����ģʽ  *********/
		case assist_mode ://����
			Fire_Bullet=0;
		  flag_shoot_back=Pc_Data.flag_shoot;
			temp_yaw 	=Pc_Data.yaw;
			temp_pitch	=Pc_Data.pitch;
			temp_yaw_B=(float)MainBoard.Yaw/(float)1000.0;
		  temp_pitch_B=(float)MainBoard.Pitch/(float)1000.0;
			motor.pitch.target.angle =motor.pitch.target.angle+temp_pitch/(float)50.0+temp_pitch_B;	//��Ҫ�޸�
			mpu.yaw.target.angle = mpu.yaw.target.angle+temp_yaw/(float)50.0+temp_yaw_B;//��Ҫ�޸�


		
	  break;
		
		default:
			
			break;
  }
			
		if(motor.pitch.target.angle > PITCH_DOWN_LIMIT)
		  motor.pitch.target.angle = PITCH_DOWN_LIMIT;
	  else if(motor.pitch.target.angle < PITCH_UP_LIMIT)
			motor.pitch.target.angle = PITCH_UP_LIMIT;
	
		
		MotorAngleLimit = mpu.yaw.present.angle + (YAW_LEFT_LIMIT - motor.yaw.present.angle_t);//left limit
		//LIMIT_L=MotorAngleLimit;
		mpu.yaw.target.angle = mpu.yaw.target.angle < MotorAngleLimit ? MotorAngleLimit : mpu.yaw.target.angle;//Ŀ���޷�	
		
		
		MotorAngleLimit = mpu.yaw.present.angle + (YAW_RIGHT_LIMIT - motor.yaw.present.angle_t);// right limit of yaw axis
		//LIMIT_R=MotorAngleLimit;
		mpu.yaw.target.angle = mpu.yaw.target.angle > MotorAngleLimit ? MotorAngleLimit : mpu.yaw.target.angle;//Ŀ���޷�	
	  
}

/**************************************************************************
*@date  2016-11-18 16:31:13
*@brief ����̨������Ϳ�����Ϣ
*
**************************************************************************/
void Pan_Tilt_Motor(CAN_Message_ID Motor_ID,int16_t Yaw_current,int16_t Pitch_current)
{  
    uint8_t send_data[8]={0};
    send_data[0] = (unsigned char)( Yaw_current>> 8);
    send_data[1] = (unsigned char)Yaw_current;
    send_data[2] = (unsigned char)( Pitch_current>> 8);
    send_data[3] = (unsigned char)Pitch_current;
		send_data[4] = 0x00;
		send_data[5] = 0x00;
		send_data[6] = 0x00;
		send_data[7] = 0x00;
		SendMessageToCANQueue(1,Motor_ID, send_data);
}

/**************************************************************************
*@date  2016-11-18 16:31:13
*@brief �ϵ���̨λ�ó�ʼ�������У�
*@Ares
**************************************************************************/
void Pan_Tilt_Position_Init(void)
{
	//���û�е��������
	static uint8_t flag_yaw=1,flag_pitch=1,flag_first=1;
	
	if(flag_first)
	{
		flag_first=0;
		motor.yaw.target.angle		= motor.yaw.present.angle_t;   //��¼��ʼ�Ƕ�
		motor.pitch.target.angle	= motor.pitch.present.angle_t;
	}
	
	if(motor.yaw.present.angle<-2 && flag_yaw)
		motor.yaw.target.angle += 0.20F;
	else if(motor.yaw.present.angle>2 && flag_yaw)
		motor.yaw.target.angle -= 0.20F;
	if((motor.yaw.present.angle >-2)&&(motor.yaw.present.angle <2))
	{
		flag_yaw=0;
		motor.yaw.target.angle =0;
		can1_send_motor_mid_value=motor.yaw.target.angle;
	}
	
	if(motor.pitch.present.angle<-2 && flag_pitch)
		motor.pitch.target.angle += 0.20F;
	else if(motor.pitch.present.angle>2 && flag_pitch)
		motor.pitch.target.angle -= 0.20F;
	if((motor.pitch.present.angle>-2) && (motor.pitch.present.angle<2))
	{
		motor.pitch.target.angle = 0;
		flag_pitch=0;
	}
	
	mpu.yaw.target.angle = mpu.yaw.present.angle;//��¼�ռ�yaw�Ƕ�
	wheel[WHE_DIAL].angle_target=	wheel[WHE_DIAL].angle_present	;  //��¼���ֽǶ�
	motor.yaw.output	= Motor_Yaw_Control(&motor);
	motor.pitch.output	= Motor_Pitch_Control( &motor );
#if PAN_NORMAL
  Pan_Tilt_Motor(PTZ_OUTID,(int16_t)(motor.yaw.output), (int16_t)(motor.pitch.output));
#endif
}
/**************************************************************************
*@date  2017-3-24 10:47:00
*@brief �����ת����
*@Ares
**************************************************************************/
void Motor_Protect(void)
{
	static uint16_t cnt_yaw=0,cnt_pitch=0;

	if(fabs(mpu.yaw.position.increment)==3000)
		cnt_yaw++;
	else 
		cnt_yaw=0;

	if(fabs(motor.pitch.position.increment)==3000)
		cnt_pitch++;
	else 
		cnt_pitch=0;
	
	if((cnt_yaw>600) || (cnt_pitch>600))
		flag_over_current = 1;
}

/**************************************************************************
*@date  2016-11-18 20:18:55
*@brief ��̨����
*�����û�е����
*��������ͨģʽyaw����mpu����
**************************************************************************/
void Pan_Tilt_Control()
{
	static uint8_t flag_switch=0;
	error_pitch = fabs(motor.pitch.present.angle - Pc_Data.pitch);//����Ƕ�ƫ��
	error_yaw = fabs(motor.yaw.present.angle - Pc_Data.yaw);
	
	switch(MainBoard.Flag_Mode)
	{
		case rune_big_mode:
		case rune_mode://���ģʽ 
			if(flag_switch!=1)
			flag_switch=1;
			break;
		case assist_mode:
			if(flag_switch!=2) //�������ģʽ yawΪmpu����
			{
				mpu.yaw.target.angle	= mpu.yaw.present.angle;	//��¼��ǰ�Ƕ�
			  flag_switch=2;
			}
			break;
		case rune_dema:
			if(flag_switch!=3)
			flag_switch=3;
			break;
		case nomal_mode:
			if(MainBoard.Control_Flag==0)
			{
				if(flag_switch!=4)
				  flag_switch=4;
			}
			else
			{
				if(flag_switch!=5)
				{
					mpu.yaw.target.angle	= mpu.yaw.present.angle;
				  flag_switch=5;
				}
			}
			break;
		default :
			flag_switch=4;
			break;
	}
	Calculate_Target();
	
	if(flag_switch == 1) //���
	{
	  PanTiltToBoard(ANGLE_ID,0,Bullet_Sent);
		PanTiltToBoard(BIGFU_ID,Pc_Data.distance,Pc_Data.gray);
		motor.yaw.output = Motor_Yaw_Control(&motor);//���ģʽyaw���û�е����
		motor.pitch.output 	= Motor_Pitch_Control( &motor );//pitchʼ�ղ��û�еģʽ
		
		#if PAN_NORMAL
  	Pan_Tilt_Motor(PTZ_OUTID,(int16_t)(motor.yaw.output), (int16_t)(motor.pitch.output));//���Ϳ�����Ϣ�����
	  #endif
	}
	else if(flag_switch==2)
	{
		angle=motor.yaw.present.angle_t-can1_send_motor_mid_value;
		 //angle2=(int16_t)angle;
		 PanTiltToBoard(ANGLE_ID,angle,Bullet_Sent);
		mpu.yaw.output =MPU_Yaw_Control(&mpu);//yaw �ռ���
		//motor.pitch.output 	= Motor_Pitch_Assist_Control( &motor );//
		
		//mpu.yaw.output =MPU_Yaw_Control(&mpu);
		motor.pitch.output 	= Motor_Pitch_Control( &motor );
		#if PAN_NORMAL
		 Pan_Tilt_Motor(PTZ_OUTID,(int16_t)(mpu.yaw.output), (int16_t)(motor.pitch.output));//���Ϳ�����Ϣ�����
	  #endif 
	}
	else if(flag_switch==3)
	{
		 PanTiltToBoard(ANGLE_ID,0,0);
		 motor.yaw.output = Motor_Yaw_Control( &motor );
		motor.pitch.output 	= Motor_Pitch_Control( &motor );//pitchʼ�ղ��û�еģʽ
		#if PAN_NORMAL
  	Pan_Tilt_Motor(PTZ_OUTID,(int16_t)(motor.yaw.output), (int16_t)(motor.pitch.output));//���Ϳ�����Ϣ�����
	  #endif
	}	
	else if(flag_switch==4)
	{
		 angle=motor.yaw.present.angle_t-can1_send_motor_mid_value;
		 //angle2=(int16_t)angle;
		 PanTiltToBoard(ANGLE_ID,angle,Bullet_Sent);
		 motor.pitch.target.angle=0;
			/****** pitch���е yaw��Ϊ��е******/	
	   motor.yaw.output = Motor_Yaw_Control(&motor);//yaw 
		motor.pitch.output 	= Motor_Pitch_Control( &motor );//pitchʼ�ղ��û�еģʽ
		
		#if PAN_NORMAL
		 Pan_Tilt_Motor(PTZ_OUTID,(int16_t)(motor.yaw.output), (int16_t)(motor.pitch.output));//���Ϳ�����Ϣ�����
	  #endif 
	}
	else
	{
		angle=motor.yaw.present.angle_t-can1_send_motor_mid_value;
		 //angle2=(int16_t)angle;
		 PanTiltToBoard(ANGLE_ID,angle,Bullet_Sent);
			/****** pitch���е yaw��Ϊ*****/	
	   mpu.yaw.output = MPU_Yaw_Control(&mpu);//yaw �ռ����
		motor.pitch.output 	= Motor_Pitch_Control( &motor );//pitchʼ�ղ��û�еģʽ
		#if PAN_NORMAL
		 Pan_Tilt_Motor(PTZ_OUTID,(int16_t)(mpu.yaw.output), (int16_t)(motor.pitch.output));//���Ϳ�����Ϣ�����
	  #endif 
	}
}

