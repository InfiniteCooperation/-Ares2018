/**
  ******************************************************************************
  * @file    task_frictiongear.c
  * @author  AresZzz��ֲ
  * @version V1.0
  * @date    2018/04/17
  * @brief   Ħ���֡����ֿ���
  * 
  ******************************************************************************
  * @attention
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "task_init.h"
/* Defines -------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
_WHEEL wheel[4]={0};
_WHEEL dial;
uint8_t wheel_status=0;
uint16_t jishu=0;
uint16_t cnt=0;
extern int wave[4];
int Fc_Speed[2];
uint32_t last_shoot_time1=0;

float angle_charge;
int8_t fc_flag=0;//Ħ���ָտ���־��1ʱ��ʼ�򵰼���
int8_t cs_flag=1;

extern uint8_t All_Complite;
uint8_t Fire_Complite=0;

uint8_t First_Sign=1;
uint8_t Fire_Bullet=0;

uint8_t Charge_Time=0;
extern uint8_t Speed_Over;
uint16_t error_check1=0;
uint16_t error_check=0;
uint16_t error_check2=0;
/* Function  -----------------------------------------------------------------*/

void Wheel_Param_Init(void) //Ħ���ֲ�����ʼ��
{
#if defined(Azrael)
	wheel[WHE_LEFT].k_p = 12;
	wheel[WHE_LEFT].k_i = 4;
	wheel[WHE_LEFT].k_d = 25;
//	wheel[WHE_LEFT].speed_target = 6000;  
	
	wheel[WHE_RIGHT].k_p = 12;
	wheel[WHE_RIGHT].k_i = 4;
	wheel[WHE_RIGHT].k_d = 25;
//	wheel[WHE_RIGHT].speed_target =-6000;

	wheel[WHE_DIAL].k_p =50;//bo��
	wheel[WHE_DIAL].k_i = 1;
	wheel[WHE_DIAL].k_d = 30;
	wheel[WHE_DIAL].speed_target =0;
	
	wheel[WHE_DIAL].position.kp=15;
	wheel[WHE_DIAL].position.ki=0;
	wheel[WHE_DIAL].position.kd=60;
	
	
	wheel[WHE_DIAL].velocity.kp=20;
	wheel[WHE_DIAL].velocity.ki=0;
	wheel[WHE_DIAL].velocity.kd=50;
#endif

#if defined(BigHead)
	wheel[WHE_LEFT].k_p = 12;
	wheel[WHE_LEFT].k_i = 4;
	wheel[WHE_LEFT].k_d = 25;
//	wheel[WHE_LEFT].speed_target = 6000;  
	
	wheel[WHE_RIGHT].k_p = 11;
	wheel[WHE_RIGHT].k_i = 4;
	wheel[WHE_RIGHT].k_d = 30;
//	wheel[WHE_RIGHT].speed_target =-6000;

	wheel[WHE_DIAL].k_p =50;//bo��
	wheel[WHE_DIAL].k_i = 3;
	wheel[WHE_DIAL].k_d = 30;
	wheel[WHE_DIAL].speed_target =0;
	
	wheel[WHE_DIAL].position.kp=15;
	wheel[WHE_DIAL].position.ki=0;
	wheel[WHE_DIAL].position.kd=60;
	
	
	wheel[WHE_DIAL].velocity.kp=12;
	wheel[WHE_DIAL].velocity.ki=0;
	wheel[WHE_DIAL].velocity.kd=40;
#endif

#if defined(Ares)
	wheel[WHE_LEFT].k_p = 12;
	wheel[WHE_LEFT].k_i = 4;
	wheel[WHE_LEFT].k_d = 25;
//	wheel[WHE_LEFT].speed_target = 6000;  
	
	wheel[WHE_RIGHT].k_p = 11;
	wheel[WHE_RIGHT].k_i = 3;
	wheel[WHE_RIGHT].k_d = 30;
//	wheel[WHE_RIGHT].speed_target =-6000;

	wheel[WHE_DIAL].k_p =50;//bo��
	wheel[WHE_DIAL].k_i = 1;
	wheel[WHE_DIAL].k_d = 30;
	wheel[WHE_DIAL].speed_target =0;
	
	wheel[WHE_DIAL].position.kp=15;
	wheel[WHE_DIAL].position.ki=0;
	wheel[WHE_DIAL].position.kd=60;
	
	
	wheel[WHE_DIAL].velocity.kp=12;
	wheel[WHE_DIAL].velocity.ki=0;
	wheel[WHE_DIAL].velocity.kd=60;
#endif
  Fc_Speed[0]=6200;
	Fc_Speed[1]=4700;

}


/**************************************************************************
*@date  2018-3-16 
*@brief ���3510Ħ���ֿ���
**************************************************************************/
void Wheel_Sent(CAN_Message_ID Motor_ID,int16_t Wheel_A,int16_t Wheel_B,int16_t Dial,int16_t Wheel_D)
{
    uint8_t send_data[8]={0};
		send_data[0] = (uint8_t)(Wheel_A >> 8);
		send_data[1] = (uint8_t)Wheel_A;
		send_data[2] = (uint8_t)(Wheel_B >> 8);
		send_data[3] = (uint8_t)Wheel_B;
		send_data[4] = ((uint8_t)(Dial>>8)); 
		send_data[5] = ((uint8_t)(Dial));
		send_data[6] = 0x00;
		send_data[7] = 0x00;
		SendMessageToCANQueue(1,Motor_ID, send_data);
}

float Wheel_LEFT_Control(_WHEEL *whe)   //Ħ���ֵ��A
{
	/*if(Mboard.flag_mocalun_v_switch=='S')
	{
		wheel[WHE_LEFT].speed_target=5000;
	}
	else if(Mboard.flag_mocalun_v_switch=='F')
	{
		wheel[WHE_LEFT].speed_target=7000;
	}*/
	//else if(Mboard.flag_mocalun_v_switch=='M')
	//{
	wheel[WHE_LEFT].speed_target=Fc_Speed[MainBoard.Speed_Control]; 
	//}
  whe->error[2]=whe->error[1];
	whe->error[1]= whe->error[0];
	whe->error[0]=whe->speed_target - whe->speed_present;
	
	whe->output+= wheel[WHE_LEFT].k_p*(whe->error[0]-whe->error[1])\
	                                 + whe->k_i*(whe->error[0])\
	                                 + whe->k_d*(whe->error[0]-2*whe->error[1]+whe->error[2]);					
	if(whe->output > 5000)//����޷�
		whe->output = 5000;
	else if(whe->output <= -5000)
		whe->output = -5000;	
  return whe->output;
		
	}

float Wheel_RIGHT_Control(_WHEEL *whe)   //Ħ���ֵ��B
{
	/*if(Mboard.flag_mocalun_v_switch=='S')
	{
		wheel[WHE_RIGHT].speed_target=-5000;//20
	}	
	else if(Mboard.flag_mocalun_v_switch=='F')
	{
		wheel[WHE_RIGHT].speed_target=-7000;//11
	}*/
	//else if(Mboard.flag_mocalun_v_switch=='M' )
	//{
		wheel[WHE_RIGHT].speed_target=-Fc_Speed[MainBoard.Speed_Control];//15
	//}
	whe->error[2]=whe->error[1];
	whe->error[1]= whe->error[0];
	whe->error[0]= whe->speed_target - whe->speed_present;
	
	whe->output+=whe->k_p*(whe->error[0]-whe->error[1])\
	                                 + whe->k_i*(whe->error[0])\
	                                 + whe->k_d*(whe->error[0]-2*whe->error[1]+whe->error[2]);
											
	if(whe->output > 5000)//����޷�
		whe->output = 5000;
	else if(whe->output <= -5000)
		whe->output = -5000;	
  return whe->output;
	}

void Check_Bullet(void)
{
	
}
	
void Rune_Calucation(_WHEEL *whe)//������ֿ���
{
	int bullet_n=0;
	static int bullet_back=0;
	static uint8_t First_Shoot=0;
	//float angle_charge;
	//float n;
	//angle_charge=whe->angle_present-whe->angle_target;
	if(All_Complite==1 ) //��̨����Ƕ�
  {
		 
		bullet_back=Bullet_cnt;
		Fire_Bullet=1;
		All_Complite=0;
		First_Shoot=0;
		last_shoot_time1=0;
		error_check2++;
	}
		 if(Fire_Bullet==1)
		 {
			 if(First_Shoot==0)
			 {
				 error_check1++;
				 whe->angle_target-=72;
				 if(whe->angle_target>360)
					whe->angle_target=whe->angle_target-360;
			   if(whe->angle_target<=0)
					whe->angle_target=whe->angle_target+360;
				 First_Shoot=1;
				 bullet_back=Bullet_cnt;
				 last_shoot_time1=0;
			 }
			 else
			 {
				 bullet_n=Bullet_cnt-bullet_back;
				 if(bullet_n==0) //��û���ȥ
				 {
					 last_shoot_time1++;
					 if(last_shoot_time1>=400)
				  {
						error_check++;
					  whe->angle_target-=72;
						if(whe->angle_target>360)
							whe->angle_target=whe->angle_target-360;
						if(whe->angle_target<=0)
							whe->angle_target=whe->angle_target+360;  
						last_shoot_time1=0;
				  }
				 }
				 else
				 {
					 Fire_Bullet=0;
				 }
			  }
	
   }
}

void Rune_Calucation2(_WHEEL *whe)//������ֿ���
{
	static uint32_t last_shoot_time2=0;
	int bullet_n=0;
	static int bullet_back=0;
	//float angle_charge;
	//float n;
	if(All_Complite==1 ) //��̨����Ƕ�
  {
		 
		bullet_back=Bullet_cnt;
		Fire_Bullet=1;
		last_shoot_time2=0;
		error_check2++;
		All_Complite=0;
	}
		 if(Fire_Bullet==1)
		 {
				 bullet_n=Bullet_cnt-bullet_back;
				 if(bullet_n==0) //��û���ȥ
				 {
					 last_shoot_time2++;
					 if(last_shoot_time2>=40)
				  {
						error_check++;
					  whe->angle_target-=72;
						if(whe->angle_target>360)
							whe->angle_target=whe->angle_target-360;
						if(whe->angle_target<=0)
							whe->angle_target=whe->angle_target+360;  
						last_shoot_time2=0;
				  }
				 }
				 else
				 {
					 Fire_Bullet=0;
					 last_shoot_time2=0;
				 }
			  
		}
   
}


void Rune_Calucation3(_WHEEL *whe)//������ֿ���
{
	int bullet_n=0;
	static int bullet_back=0;
	static uint8_t First_Shoot=0;
	static int timer_n=0;
	static uint32_t whe_timer_back=0;
	
	//float angle_charge;
	//float n;
	//angle_charge=whe->angle_present-whe->angle_target;
	if(All_Complite==1 ) //��̨����Ƕ�
  {
		 
		bullet_back=Bullet_cnt;
		Fire_Bullet=1;
		All_Complite=0;
		First_Shoot=1;
		error_check2++;
	  whe_timer_back=timer_cnt;
	}
		 if(Fire_Bullet==1)
		 {
			 bullet_n=Bullet_cnt-bullet_back;
			 if(bullet_n==0) //��û���ȥ
			 {
				timer_n=timer_cnt-whe_timer_back;
				if(timer_n>=200 || First_Shoot==1)
				{
					error_check++;
					whe->angle_target-=72;
					if(whe->angle_target>360)
						whe->angle_target=whe->angle_target-360;
					if(whe->angle_target<=0)
						whe->angle_target=whe->angle_target+360; 
					First_Shoot=0;					
					whe_timer_back=timer_cnt;
				 }
				}
		  else
			{
				 Fire_Bullet=0;
			}
		}
	
   
}
	

void Rune_Calucation4(_WHEEL *whe)//������ֿ���
{
	
	if(All_Complite==1 ) //��̨����Ƕ�
  {
		 
		Fire_Bullet=1;
		All_Complite=0;
	
		error_check2++;
	}
		 if(Fire_Bullet==1)
		 {
			 
				 whe->angle_target-=72;
				 if(whe->angle_target>360)
					whe->angle_target=whe->angle_target-360;
			   if(whe->angle_target<=0)
					whe->angle_target=whe->angle_target+360;
			 Fire_Bullet=0;
		}
   
}
void Dial_Calucation(_WHEEL *whe)
{
	
/*
	static uint32_t lastshoot_time=0;
	//static uint8_t last_flag_1=0;//����ģʽ 
	float n;
	int wheel_time=0;
	
	if(MainBoard.Shoot_Flag==1 && MainBoard.Shoot_Mode==0 &&fc_flag==1)
  {

	    wheel_time=timer_cnt-lastshoot_time;
		  n=Bullet_Allow_Self();
			if(wheel_time>=150 && n>1)
		 {
				whe->angle_target-=72;
				if(whe->angle_target>360)
					 whe->angle_target=whe->angle_target-360;
				if(whe->angle_target<=0)
					 whe->angle_target=whe->angle_target+360;  
				  lastshoot_time=timer_cnt;
		 }
	 }
	*/
	 
	// #ifdef Azrael
	 static uint32_t lastshoot_time=0;
	//static uint8_t last_flag_1=0;//����ģʽ 
	float n;
	 float angle_charge;
	angle_charge=whe->angle_present-whe->angle_target;
	if(MainBoard.Shoot_Flag==1 && MainBoard.Shoot_Mode==0 &&fc_flag==1 \
		&& (angle_charge<10 && angle_charge>-250))
  {
		  lastshoot_time++;
	    //wheel_time=timer_cnt-lastshoot_time;
		if(MainBoard.Level==1)
			Charge_Time=20;
		if(MainBoard.Level==2)
			Charge_Time=12;
		if(MainBoard.Level==3 || MainBoard.Defend_Flag==1)
			Charge_Time=5;
		if(MainBoard.Speed_Control==1)
			Charge_Time=1;
		   n=Bullet_Allow_Self();
			if(lastshoot_time>=Charge_Time && n>1)
		 {
				whe->angle_target-=72;
				if(whe->angle_target>360)
					 whe->angle_target=whe->angle_target-360;
				if(whe->angle_target<=0)
					 whe->angle_target=whe->angle_target+360;  
				  lastshoot_time=0;
		 }
	 }
	 //#endif
	
	//�蹷ģʽ
	if(0)//�����ñ�־λ
	{
		if(MainBoard.Flag_Mode==1 &&n>0 )
		{
			whe->speed_target=-300;//300�ٶ�ÿ��7-8��
		}
		else
			whe->speed_target=0;
	}
	
}
float Dial_Increment_Control(_WHEEL *whe)   //�ٶ� ����
{
  whe->error[2]= whe->error[1];
	whe->error[1]= whe->error[0];
	whe->error[0]= whe->speed_target-whe->speed_present;
	
	whe->output+= whe->k_p*(whe->error[0]-whe->error[1])
                                + whe->k_i*(whe->error[0])
                                + whe->k_d*(whe->error[0]-2*whe->error[1]+whe->error[2]);
	if(whe->output > 3000)//����޷�
		whe->output = 3000;
	else if(whe->output <= -3000)
		whe->output = -3000;	
  
   return whe->output;
}

float Dial_Position_Control(_WHEEL *whe)  //λ�ÿ���
{	
	whe->output=0;
		/********* λ�ã��Ƕȣ��� *****************/
	whe->position.error[1] =whe->position.error[0] ; 
	whe->position.error[0] = whe->angle_target- whe->angle_present;//˳ʱ��תʱ������error < 0�����
		
	if(whe->position.error[0]<-180)  whe->position.error[0]=360+whe->position.error[0];
	if(whe->position.error[0]>180)  whe->position.error[0]=whe->position.error[0]-360;
  whe->position.increment +=  whe->position.error[0];
	
	if(whe->position.increment>1000)//�����޷� 
		whe->position.increment=1000;
	else if(whe->position.increment<-1000)
	  whe->position.increment=-1000;
	
	whe->position.pid_out =  whe->position.kp * whe->position.error[0]\
								 + whe->position.ki * whe->position.increment\
								 + whe->position.kd * (whe->position.error[0]-whe->position.error[1]);//�ҳ�yaw��Ӧ�ĽǼ��ٶȣ�����

	if(whe->position.pid_out > CURRENT_MAX)
		whe->position.pid_out = CURRENT_MAX;
	else if(whe->position.pid_out < -CURRENT_MAX)
		whe->position.pid_out = -CURRENT_MAX;
	
/*****************�ٶȻ�*******************************************************/
  whe->velocity.error[1] = whe->velocity.error[0];//����ƫ��
	
	whe->velocity.error[0] = whe->position.pid_out - whe->speed_present;//�����ٶȻ�ƫ��
	
  whe->velocity.pid_out = whe->velocity.kp * whe->velocity.error[0]\
								   + whe->velocity.kd * (whe->velocity.error[0] - whe->velocity.error[1]);	
	
	if(whe->velocity.pid_out > CURRENT_MAX)//����޷�
		whe->velocity.pid_out = CURRENT_MAX;
	else if(whe->velocity.pid_out < -CURRENT_MAX)
		whe->velocity.pid_out = -CURRENT_MAX;	
  return whe->velocity.pid_out;
		
}
float Dial_Control(_WHEEL *whe)
{
	
	float out;
	switch(MainBoard.Flag_Mode)
	{
		case rune_big_mode:
		case rune_mode:
			Rune_Calucation3(whe);
		break;
			default:
				Dial_Calucation(whe);
			break;
	}

	//if(1)//�����ñ�־λ
	//	out=Dial_Increment_Control(whe);
//	else
	out=Dial_Position_Control(whe);
	return out;
}
	
void frictiongear_Control()  //�����������
{
	static uint32_t fc_timer=0,cs_timer=0;
	static uint8_t start_flag=1,start_flag1=1;
	static uint8_t cs_back=0;
	int timer_n,timer_n1;
	if(MainBoard.Frictiongear_Flag==1)  //Ħ����
	{
		
		 if(start_flag==1)
		 {
			 fc_timer=timer_cnt;
			 start_flag=0;
		 }
		 else
		 {
			 timer_n=timer_cnt-fc_timer;
			 if(timer_n>1000)
			 {
				 fc_flag=1;
			 }
		 }
		 
		 if(MainBoard.Speed_Control!=cs_back)
		 {
			 start_flag1=0;
			 cs_flag=0;
		 }
		 else
		 {
			 cs_timer=timer_cnt;
		 }
		 if(start_flag1==0)
		 {
			 timer_n1=timer_cnt-cs_timer;
			 if(timer_n1>1000)
			 {
				 cs_flag=1;
				 start_flag1=1;
				 cs_back=MainBoard.Speed_Control;
			 }
		 }
		 
     LASER_ON();
		 /*if(MainBoard.Flag_Mode==rune_mode || MainBoard.Flag_Mode==rune_big_mode)
			 LASER_OFF();*/
	   wheel[WHE_LEFT].output=Wheel_LEFT_Control(&wheel[WHE_LEFT]);
	   wheel[WHE_RIGHT].output=Wheel_RIGHT_Control(&wheel[WHE_RIGHT]);		
		 wheel[WHE_DIAL].output=Dial_Control(&wheel[WHE_DIAL]);
		
	}
	else
	{
		 start_flag=1;
		 fc_flag=0;
		 wheel[WHE_DIAL].angle_target=wheel[WHE_DIAL].angle_present;
	   wheel[WHE_LEFT].output=0;
		 wheel[WHE_RIGHT].output=0;
		 wheel[WHE_DIAL].output=0;
		 LASER_OFF();
	}
	
	Wheel_Sent(FRICITION_CONTROL,(int16_t)wheel[WHE_RIGHT].output,(int16_t)wheel[WHE_LEFT].output,(int16_t)wheel[WHE_DIAL].output,0);
}

void Cartridge_Control(void)
{
	if(MainBoard.Cartridge==1)
		user_pwm_setvalue(CARTRIDGE_OPEN);
	if(MainBoard.Cartridge==0)
		user_pwm_setvalue(CARTRIDGE_CLOSE);
}
	
