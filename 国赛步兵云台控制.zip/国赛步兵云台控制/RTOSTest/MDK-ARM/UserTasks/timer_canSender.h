#ifndef __TIMER_CANSENDER_H
#define __TIMER_CANSENDER_H

#include "stm32f4xx_hal.h"
#include "cmsis_os.h"
#include "bsp_can.h"


extern uint32_t timer_cnt;

/** 
  * @brief  CAN_Message_TypeDef  struct
  */
typedef struct
{
	uint8_t     CANx;               //CAN���     1 CAN1      2 CAN2
  CAN_Message_ID  emCAN_ID;
  uint8_t         u8_Data[8];
}CAN_Message_TypeDef;


BaseType_t SendMessageToCANQueue(uint8_t CANX,CAN_Message_ID _id, uint8_t* _message);
 void CanSenderTimerCreate(void);



#endif
