#ifndef _TASK_SELFCHECK_
#define _TASK_SELFCHECK_
#include <stm32f4xx.h>
#include "bsp_ptz_control.h"

#define _CAN_ERROR 1
#define _CAN_GOOD  0

#define ERROR_PITCH  1
#define ERROR_YAW    2
#define ERROR_RIGHT  3
#define ERROR_LEFT   4
#define ERROR_DIAL   5
#define ERROR_MBOARD 6
#define ERROR_DIAL_S 7

typedef struct 
{
	uint32_t Present;
	uint32_t Past;
}_CNT;

typedef struct 
{
	_CNT CAN1_Pitch;
	_CNT CAN1_Yaw;
	_CNT CAN1_Wheel_Right;
	_CNT CAN1_Wheel_Left;
	_CNT CAN1_Wheel_Dial;
	_CNT CAN2_Mboard;
	_CNT USART_Pc;
}_FRAME;

extern _FRAME frame;
extern uint8_t ErrorMessage;
void selfCheckTaskThreadCreate(osPriority taskPriority);
#endif

