#ifndef __TASK_COMMAND_H
#define __TASK_COMMAND_H

#include "stm32f4xx_hal.h"
#include "cmsis_os.h"
void PC_Send_Message(void);
void CommandTaskThreadCreate(osPriority taskPriority);
#endif
