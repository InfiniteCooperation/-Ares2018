/**
  ******************************************************************************
  * @file    task_command.c
  * @author  
  * @version V1.1
  * @date    2018/04/14
  * @brief   �������񣬼��ϴ��ڷ�����λ��
  * 
  ******************************************************************************
  * @attention 
  *			
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "task_init.h"
/* Defines -------------------------------------------------------------------*/
#define COMMAND_PERIOD 20
/* Variables -----------------------------------------------------------------*/
uint8_t k_count=0;
osThreadId  CommandTaskHandle;
/**************************************************************************
*@date  2018-3-18 21:02:30
*@brief ��PC������Ϣ                 
**************************************************************************/
void PC_Send_Message(void)
{
	//static uint8_t flag_dem=0,flag_send=0,num_send=0,flag_cnt_rune=2,cnt_shoot_delay=0;
	uint8_t temp_data[4];
	
	//Mboard.Flag_Mode=assist_mode;//��ʱ�����ط�������ģʽ����Ϊ���ģʽ�����������ؼ���������ƣ�
	
	switch (MainBoard.Flag_Mode)
	{
		case rune_mode ://da��ģʽ rune_mode 	='d',  0x64  //���Ը��ҷ��ͺ�+1     �����Է��ͺ�+1
			temp_data[0] ='s';//2 'u' 'd' 'n'
		  temp_data[1] =0;
		  temp_data[2]=0;
		  temp_data[3]=0;
		 UART_Send_Buff(&PTZ_HUART,rune_mode,temp_data,4);
		break;

		case assist_mode://assist_mode	='c',	    0x63
     // flag_send=0;
			*(int16_t*)&temp_data[0] = mpu.yaw.present.angle;
			*(int16_t*)&temp_data[2] = motor.pitch .present .angle ;
			UART_Send_Buff(&PTZ_HUART,assist_mode,temp_data,4);
		break;
		
		case nomal_mode:
			temp_data[0] =Pc_Data.BaoGuang;
		  temp_data[1] =0;
		  temp_data[2]=0;
		  temp_data[3]=0;
			UART_Send_Buff(&PTZ_HUART,nomal,temp_data,4);
		break;
		case rune_big_mode:
			temp_data[0] ='b';
		  temp_data[1] =0;
		  temp_data[2]=0;
		  temp_data[3]=0;
		 UART_Send_Buff(&PTZ_HUART,rune_mode,temp_data,4);
			break;
		default:
			break;
	}
}
/**
  * @brief  ��������
  * @param  void const * argument
  * @retval None
  */
void CommandTask(void const * argument)
{	
 
	osDelay(200);//�ӳ�100ms
  portTickType xLastWakeTime;
  xLastWakeTime = xTaskGetTickCount();
  for(;;)
  { 
	
		PC_Send_Message();
			
	  osDelayUntil(&xLastWakeTime, COMMAND_PERIOD);
  }
}


/**
  * @brief  Create the DebugTask threads
  * @param  None
  * @retval None
  */
void CommandTaskThreadCreate(osPriority taskPriority)
{
	osThreadDef(commandTask, CommandTask, taskPriority, 0, 128);
  CommandTaskHandle = osThreadCreate(osThread(commandTask), NULL);
}
