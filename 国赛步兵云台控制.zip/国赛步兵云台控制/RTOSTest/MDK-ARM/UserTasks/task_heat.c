/**
  ******************************************************************************
  * @file    timer_heat.c
  * @author  AresZzz��ֲ
  * @version V1.0
  * @date    2018/04/17
  * @brief   ��������
  * 
  ******************************************************************************
  * @attention  
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "task_init.h"
/* Defines -------------------------------------------------------------------*/
#define HEAT_PERIOD     5         //����5MS
#define COLD_PERIOD     100         //����100MS
/* Variables -----------------------------------------------------------------*/
osThreadId HeatcoldTaskHandle;
osThreadId HeatcontrolTaskHandle;
int16_t Bullet_flag=0;
int16_t Bullet_cnt=0;
int16_t Bullet_temp=0;
_HEAT heat={0};
uint8_t Speed_Over=0;
extern int8_t bullet_flag_r;
uint16_t Wheel_Speed_L,Wheel_Speed_R;

extern int wave[4];

extern int8_t bullet_flag_r;
extern int8_t fc_flag;
extern uint16_t Bullet_Sent;

/* Function  -----------------------------------------------------------------*/

void Heat_Param_Init(void)
{
	heat.SelfLevel=1;
	heat.SpeedLevel=MED;
	heat.Level[1].Max_Heat=LEVEL1_17MAXHEAT;
	heat.Level[1].Cold_Heat=LEVEL1_17COLDHEAT;
	heat.Level[2].Max_Heat=LEVEL2_17MAXHEAT;
	heat.Level[2].Cold_Heat=LEVEL2_17COLDHEAT;
	heat.Level[3].Max_Heat=LEVEL3_17MAXHEAT;
	heat.Level[3].Cold_Heat=LEVEL3_17COLDHEAT;
	heat.Bullet_Speed_Meg[SLOW]=BULLETSPEED_17_S;
	heat.Bullet_Speed_Meg[MED] =BULLETSPEED_17_M;
	heat.Bullet_Speed_Meg[FAST]=BULLETSPEED_17_F;
	
}
//�����ӵ���
/*void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	static uint32_t timer_back=0;
	uint32_t timer_n=0;
	timer_n=timer_cnt-timer_back;
	if(timer_n>=20)
	{
		Bullet_flag=1;
		
	}

	//timer_n=0;
	timer_back=timer_cnt;
}*/

//
void Heat_Caculation(void)
{
	static int16_t bullet_back=0;
	
	heat.SpeedLevel=MainBoard.Speed_Control;
	if(MainBoard.Level>0 &&  MainBoard.Level<4)
	{
		heat.SelfLevel=MainBoard.Level;
	}
	if(MainBoard.Cartridge==1)
			Bullet_Sent=0;
	heat.BulletSpeed=heat.Bullet_Speed_Meg[heat.SpeedLevel];
	if(Bullet_cnt-bullet_back>=1)
	{
		heat.HeatCaculate+=heat.BulletSpeed;
		bullet_back=Bullet_cnt;
		Bullet_Sent++;
	}
}

float Bullet_Allow_Jugement(void)
{
	float temp;
	float n;
	temp=heat.Level[heat.SelfLevel].Max_Heat-MainBoard.Heat_Back;
	if(temp>0)
	{
		 n=temp/heat.Bullet_Speed_Meg[heat.SpeedLevel];
	}
	 else
		 n=0;
	return n-1;
}

float Bullet_Allow_Self(void)
{
	//static uint8_t default_cnt=0;
	static uint8_t big_cnt=0;
	float temp;
	float n;
	if(MainBoard.JugeMent_Confirm==0)
	{
		if(MainBoard.Bullet_Speed>=25)
			Speed_Over=1;
		 if(heat.HeatCaculate<MainBoard.Heat_Back)
	  {
		  heat.HeatCaculate=MainBoard.Heat_Back;
	  }
		if(heat.HeatCaculate-MainBoard.Heat_Back>=10 && MainBoard.Heat_Back!=0)
		{
			big_cnt++;
			if(big_cnt>20)
			{
				heat.HeatCaculate=MainBoard.Heat_Back;
				big_cnt=0;
			}
		}
		
		if(heat.Bullet_Speed_Meg[heat.SpeedLevel]<MainBoard.Bullet_Speed && MainBoard.Bullet_Speed-heat.Bullet_Speed_Meg[heat.SpeedLevel]<2)
		{
			heat.Bullet_Speed_Meg[heat.SpeedLevel]=MainBoard.Bullet_Speed;
		}
			
	}
  temp=heat.Level[heat.SelfLevel].Max_Heat-heat.HeatCaculate;
	if(temp>0)
	{
		 n=temp/heat.Bullet_Speed_Meg[heat.SpeedLevel];
	}
	else
		  n=0;
	return n;
}

//���������߳�
void HeatcontrolTask(void const * argument)
{
  osDelay(200);//�ӳ�500ms
  portTickType xLastWakeTime;
  xLastWakeTime = xTaskGetTickCount(); 
  for(;;)
  {	
		Heat_Caculation();
		osDelayUntil(&xLastWakeTime, HEAT_PERIOD);
	}
}

void HeatcontrolTaskThreadCreate(osPriority taskPriority)
{
	osThreadDef(HeatTask, HeatcontrolTask, taskPriority, 0, 64);
  HeatcontrolTaskHandle = osThreadCreate(osThread(HeatTask), NULL);
}
//10Hz����ȴ�߳�
void HeatcoldTask(void const * argument)
{
  osDelay(100);//�ӳ�100ms
  portTickType xLastWakeTime;
  xLastWakeTime = xTaskGetTickCount();
  for(;;)
  {	
		//����ֵ
		if(MainBoard.Defend_Flag==0)
		{
			if(MainBoard.Blood_Flag==0)
			{
				if(heat.HeatCaculate>0)
					heat.HeatCaculate-=heat.Level[heat.SelfLevel].Cold_Heat/(float)10.0;
				if(heat.HeatCaculate<=0)
					heat.HeatCaculate=0;
			}
		  else
			{
				if(heat.HeatCaculate>0)
					heat.HeatCaculate-=heat.Level[heat.SelfLevel].Cold_Heat/(float)5.0;
				if(heat.HeatCaculate<=0)
					heat.HeatCaculate=0;
			}
			
		}
		else
		{
			if(heat.HeatCaculate>0)
				heat.HeatCaculate-=heat.Level[heat.SelfLevel].Cold_Heat/(float)2.0;
			if(heat.HeatCaculate<=0)
				heat.HeatCaculate=0;
		}
		//osDelay(100); 
		//����ֵ
		/*switch(heat.SelfLevel)
		{
			case 1:if(heat.HeatBack>=0)
							heat.HeatBack-=LEVEL1_17MAXHEAT/10.0;break;
			case 2:if(heat.HeatBack>=0)
							heat.HeatBack-=LEVEL2_17MAXHEAT/10.0;break;
			case 3:if(heat.HeatBack>=0)
							heat.HeatBack-=LEVEL3_17MAXHEAT/10.0;break;
			default: break;
	 }
		if(heat.HeatBack<=0)
			heat.HeatBack=0;*/
		osDelayUntil(&xLastWakeTime, COLD_PERIOD);
	}
}

void HeatcoldTaskThreadCreate(osPriority taskPriority)
{
	osThreadDef(ColdTask, HeatcoldTask, taskPriority, 0, 64);
  HeatcoldTaskHandle = osThreadCreate(osThread(ColdTask), NULL);
}


void HeatTaskThreadCreat(void)
{
	HeatcontrolTaskThreadCreate(osPriorityRealtime);
	HeatcoldTaskThreadCreate(osPriorityHigh);
}
