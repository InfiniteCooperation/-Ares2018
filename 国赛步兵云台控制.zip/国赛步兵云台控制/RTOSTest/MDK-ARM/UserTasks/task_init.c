/**
  ******************************************************************************
  * @file    task_init.c
  * @author  AresZzz��ֲ
  * @version V1.0
  * @date    2018/04/17
  * @brief   
  * 
  ******************************************************************************
  * @attention
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "task_init.h"
/* Defines -------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
osThreadId initTaskHandle;
int M_pwm=150;
/* Function  -----------------------------------------------------------------*/
void Sys_Init(void)
{
	HAL_Delay(100); 
	Pan_Param_Init();
  Wheel_Param_Init();
	Heat_Param_Init();
	IIC_GPIO_Init();    	//6050I2C���ų�ʼ��
	HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_1);
	while(MPUInit());//6050��ʼ��
	while(dmp_set_init());	//6050DMP��ʼ��
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14|GPIO_PIN_15, GPIO_PIN_SET);
}

void InitTask(void const * argument)
{

  osDelay(100);
	//can��ʱ��1ms����
	Led_Task_Init();
  CanSenderTimerCreate();
	//��̨����5ms
	PtzcontrolTaskThreadCreate(osPriorityAboveNormal);
	DaControlTaskThreadCreate(osPriorityRealtime);
	
	HeatTaskThreadCreat();
	
	//���ڷ���
	CommandTaskThreadCreate(osPriorityAboveNormal);
	selfCheckTaskThreadCreate(osPriorityBelowNormal);
  osDelay(100);
  for(;;)
  {
    vTaskDelete(initTaskHandle);
  }
}


/**
  * @brief  Create the UnderpanTask threads
  * @param  None
  * @retval None
  */
void initTaskThreadCreate(osPriority taskPriority)
{
	osThreadDef(initTask, InitTask, taskPriority, 0, 64);
  initTaskHandle = osThreadCreate(osThread(initTask), NULL);
}

void TaskTest(void)
{
	
	 // wheel[WHE_DIAL].output=Dial_Increment_Control(&wheel[WHE_DIAL]);
		//Wheel_Sent(FRICITION_CONTROL,0,0,(int16_t)wheel[WHE_DIAL].output,0);
		//HAL_UART_Transmit_IT(&huart1, aTxStartMessage,sizeof(aTxStartMessage));
//	if(timer_cnt>3000 &&timer_cnt<10000 )
	 //Pan_Tilt_Position_Init();
	//if(timer_cnt>=10000)
	//{
		//Pan_Tilt_Control();
	//}
	//frictiongear_Control();
	user_pwm_setvalue(M_pwm);
}
