#ifndef __TASK_INIT_H
#define __TASK_INIT_H

#include "stm32f4xx_hal.h"
#include "cmsis_os.h"
#include "can.h"
#include "tim.h"
#include "gpio.h"
#include "usart.h"
#include "FreeRTOS.h"

#include "inv_mpu.h"
#include "inv_mpu_dmp_motion_driver.h"
#include "mpu6050_i2c.h"
#include "mpu6050.h"
#include "task_init.h"
#include "task_led.h"
#include "timer_canSender.h"
#include "task_heat.h"
#include "task_ptzcontrol.h"
#include "task_selfcheck.h"
#include "task_command.h"

#include "bsp_can.h"
#include "bsp_frictiongear.h"
#include "bsp_ptz_control.h"
#include "bsp_usart.h"
#include "iwdg.h"

void Sys_Init(void);
void initTaskThreadCreate(osPriority taskPriority);
void ALL_parameter_init(void);
void TaskTest(void);
#endif
