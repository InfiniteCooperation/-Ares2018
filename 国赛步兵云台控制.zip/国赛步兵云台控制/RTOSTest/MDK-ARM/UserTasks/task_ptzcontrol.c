/**
  ******************************************************************************
  * @file    task_ptzcontrol.c
  * @author  AresZzz��ֲ
  * @version V1.0
  * @date    2018/04/17
  * @brief   ��̨��������
  * 
  ******************************************************************************
  * @attention 
  *			
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "task_init.h"
/* Define ------------------------------------------------------------------*/
#define PTZ_PERIOD     5         //����5MS
#define DA_PERIOD     5  
/* Variables -----------------------------------------------------------------*/
osThreadId ptzcontrolTaskHandle;


osThreadId DacontrolTaskHandle;


uint32_t Stack_Size;
extern float can1_send_motor_mid_value;
extern uint32_t PcClear_Timer;
//uint8_t aTxStartMessage[] = "\r\n****UART-Hyperterminal communication based on IT ****\r\nEnter 10 characters using keyboard :\r\n";
/* Function  -----------------------------------------------------------------*/
void Ptz_Move(void)
{
	static uint16_t flag_3s=0;
		if(flag_3s<100) //��ֹ�ٻ���
		{
			flag_3s++;
		}
		else if(flag_3s<600)	
		{
			flag_3s++;	
			Pan_Tilt_Position_Init();//��̨����
		}
		else
		{
			if(timer_cnt>5000)
			{
				Pan_Tilt_Control();//��̨
				//frictiongear_Control();//Ħ����  ����
				Cartridge_Control();
				//TaskTest();
			}
			else
			{
			  motor.pitch.target.angle=0;
				motor.yaw.target.angle=0;
				motor.pitch.output 	= Motor_Pitch_Control( &motor );
	      motor.yaw.output 	= Motor_Yaw_Control( &motor );
				
				#if PAN_NORMAL
				Pan_Tilt_Motor(PTZ_OUTID,(int16_t)(motor.yaw.output), (int16_t)(motor.pitch.output));
				#endif
				mpu.yaw.target.angle = mpu.yaw.present.angle;//��¼�ռ�yaw�Ƕ�
			}
		}
		
}
//
/**
  * @brief  ��̨�˶�����
  * @param  void const * argument
  * @retval None
  */
void PtzcontrolTask(void const * argument)
{
  osDelay(200);//�ӳ�100ms
  portTickType xLastWakeTime;
  xLastWakeTime = xTaskGetTickCount();
  for(;;)
  {	
		//TaskTest();
		//Ptz_Move();
		//wheel[WHE_DIAL].angle_target=	wheel[WHE_DIAL].angle_present	;  //��¼���ֽǶ�
		//frictiongear_Control();
		
		Ptz_Move();
		PcClear_Timer++;
		osDelayUntil(&xLastWakeTime, PTZ_PERIOD);
	}
}
void DacontrolTask(void const * argument)
{
	osDelay(200);//�ӳ�100ms
  portTickType xLastWakeTime;
  xLastWakeTime = xTaskGetTickCount();
	for(;;)
  {	
		//TaskTest();
		//Ptz_Move();
		//wheel[WHE_DIAL].angle_target=	wheel[WHE_DIAL].angle_present	;  //��¼���ֽǶ�
		//frictiongear_Control();
		
		frictiongear_Control();
		osDelayUntil(&xLastWakeTime, DA_PERIOD);
	}
}


  void PtzcontrolTaskThreadCreate(osPriority taskPriority)
{
	osThreadDef(ptzTask, PtzcontrolTask, taskPriority, 0, 2048);
  ptzcontrolTaskHandle = osThreadCreate(osThread(ptzTask), NULL);
}

 void DaControlTaskThreadCreate(osPriority taskPriority)
{
	osThreadDef(daTask, DacontrolTask, taskPriority, 0, 256);
  DacontrolTaskHandle = osThreadCreate(osThread(daTask), NULL);
}

