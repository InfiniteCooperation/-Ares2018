/**
  ******************************************************************************
  * @file    timer_canSend.c
  * @author  AresZzz��ֲ
  * @version V1.0
  * @date    2018/04/17
  * @brief   can�Ķ�ʱ������,��ֹ��ռ
  * 
  ******************************************************************************
  * @attention  
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "task_init.h"
/* Defines -------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
osMessageQId canSendQueueHandle;
osTimerId canSendTimerHandle;
CAN_Message_TypeDef messageBuff;
uint32_t timer_cnt=0;
//test variable
int16_t testSpace;
HAL_StatusTypeDef testCanStatus;
/* Function  -----------------------------------------------------------------*/
void CanSendTimerCallback(void const * argument)
{
	timer_cnt++;//����ϵͳtimer 1ms
	while(xQueueReceive(canSendQueueHandle, &messageBuff, 1))
	{
  //test(OK!).......................................................................................................
    testSpace = uxQueueSpacesAvailable(canSendQueueHandle);
  //test(OK!).......................................................................................................
		if(messageBuff.CANx == 1)
		{
			//CAN��������
			if(CAN1->ESR)
			{
					CAN1->MCR |= 0x02;
					CAN1->MCR &= 0xFD;
			}
		if(CAN1->TSR & 0x1C000000)
		testCanStatus=CAN_Send_Message(&hcan1, messageBuff.emCAN_ID, messageBuff.u8_Data);
	  }
		
		if(messageBuff.CANx == 2)
		{
			//CAN��������
			if(CAN2->ESR)
			{
					CAN2->MCR |= 0x02;
					CAN2->MCR &= 0xFD;
			}		
			if(CAN2->TSR & 0x1C000000)
		testCanStatus=CAN_Send_Message(&hcan2, messageBuff.emCAN_ID, messageBuff.u8_Data);
		}

	  }		
	}


/**
  * @brief  �������ݵ�can����(���������ӵ�can���е�д��һ������)
  * @param  CAN_Message_ID _id
  * @param  int16_t* _message
  * @retval BaseType_t
  */
BaseType_t SendMessageToCANQueue(uint8_t CANX,CAN_Message_ID _id, uint8_t* _message)
{
	BaseType_t queueStatus;
	CAN_Message_TypeDef canMessageBuff;
	canMessageBuff.CANx=CANX;
  canMessageBuff.emCAN_ID = _id;//ID��ֵ
	memcpy(canMessageBuff.u8_Data,_message,8);//���ݸ�ֵ
	queueStatus = xQueueSend(canSendQueueHandle, &canMessageBuff, (TickType_t)1);
	return(queueStatus);
}


/**
  * @brief  Create the can send queue
  * @param  None
  * @retval None
  */
void CAN_QueueCreate(void)
{
  osMessageQDef(canSendQueue, 20, CAN_Message_TypeDef);
  canSendQueueHandle = osMessageCreate(osMessageQ(canSendQueue), NULL);
}


/**
  * @brief  ����can���Ͷ�ʱ��
  * @param  None
  * @retval None
  */
void CanSenderTimerCreate(void)
{
  //�ȴ�������
  CAN_QueueCreate();
  //�꺯��         ���ã�����os_timer_def_##name�ṹ��
	osTimerDef(canSendTimer, CanSendTimerCallback); 
	  //���������Ƿ��ظ��ص�  ���ã�����������ʱ��
	canSendTimerHandle = osTimerCreate(osTimer(canSendTimer), osTimerPeriodic, NULL);
	 //��ʼ��ʱ
	osTimerStart(canSendTimerHandle, 1);
}
