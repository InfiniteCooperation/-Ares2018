#ifndef __HEAT_TASK_H
#define __HEAT_TASK_H
#include "stm32f4xx_hal.h"


#define SHELL_HEAT 40  //�߶�������

#define LEVEL1_17MAXHEAT  108  //Ϊ��֤��������Сһ��
#define LEVEL1_42MAXHEAT  80
#define LEVEL1_17COLDHEAT 18.0
#define LEVEL1_42COLDHEAT 20.0

#define LEVEL2_17MAXHEAT  225//Ϊ��֤��������Сһ��
#define LEVEL2_42MAXHEAT  160
#define LEVEL2_17COLDHEAT 36.0
#define LEVEL2_42COLDHEAT 40.0

#define LEVEL3_17MAXHEAT  470//Ϊ��֤��������Сһ��
#define LEVEL3_42MAXHEAT  320
#define LEVEL3_17COLDHEAT 72.0
#define LEVEL3_42COLDHEAT 80.0
	
#define BULLETSPEED_17_S 14.5
#define BULLETSPEED_17_M 22.5
#define BULLETSPEED_17_F 25.0

#define SLOW 1
#define MED  0
#define FAST 2

extern int16_t Bullet_cnt;

typedef struct
{
	float Speed_Slow;
	float Speed_Med;
	float Speed_Fast;
}BULLET_SPEED;

typedef struct
{
	float Max_Heat;
	float Cold_Heat;
}_LEVEL;


typedef struct
{
	float HeatBack;
	float HeatCaculate;
	uint8_t ShootFlag;
	_LEVEL  Level[4];
	float BulletSpeed;
	int   AllowBullet_Num;
	float Bullet_Speed_Meg[3];
	uint8_t SelfLevel;
	uint8_t SpeedLevel;
	
}_HEAT;

void Heat_Param_Init(void);
float Bullet_Allow_Jugement(void);
float Bullet_Allow_Self(void);
void HeatTaskThreadCreat(void);
void HeatcontrolTask(void const * argument);
#endif

