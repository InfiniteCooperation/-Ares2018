/**
  ******************************************************************************
  * @file    task_led.c
  * @author  AresZzz ��ֲ
  * @version V1.0
  * @date    2018/04/17
  * @brief   led����
  * 
  ******************************************************************************
  * @attention
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "task_init.h"
/* Defines -------------------------------------------------------------------*/
#define SELFCHEK_PERIOD 100
/* Variables -----------------------------------------------------------------*/
_FRAME frame={0};
osThreadId selfCheckTaskHandle;
uint8_t ErrorMessage;
/* Function  -----------------------------------------------------------------*/

uint8_t Can_SelfCheck(_CNT CAN_Frame)
{
	if(timer_cnt>3000)
	{
		if(CAN_Frame.Present==0)
		{
			return _CAN_ERROR;
		}
	}
	
	if(CAN_Frame.Present-CAN_Frame.Past>=1)
	{
		CAN_Frame.Past=CAN_Frame.Present;
		return _CAN_GOOD;
	}
	else
	{
		CAN_Frame.Past=CAN_Frame.Present;
		return _CAN_ERROR;
	}
}
uint8_t CheckIng(void)
{
	static int n=0;
	if(Can_SelfCheck(frame.CAN1_Pitch)!=0)
		return ERROR_PITCH;
	if(Can_SelfCheck(frame.CAN1_Yaw)!=0)
		return ERROR_YAW;
	if(Can_SelfCheck(frame.CAN1_Wheel_Left)!=0)
		return ERROR_LEFT;
	if(Can_SelfCheck(frame.CAN1_Wheel_Right)!=0)
		return ERROR_RIGHT;
	if(Can_SelfCheck(frame.CAN1_Wheel_Dial)!=0)
		return ERROR_DIAL;
	if(Can_SelfCheck(frame.CAN2_Mboard)!=0)
		return ERROR_MBOARD;
	if(fabs(wheel[2].speed_present)<10 && fabs(wheel[2].output)>=2000 )
	{
		n++;
	}
	else
		n=0;
	if(n>10)
	{
		n=0;
		return ERROR_DIAL_S; 
	}
	return 0;
}

void SelfCheckTask(void const * argument)
{
	
	osDelay(100);
	portTickType xLastWakeTime;
  xLastWakeTime = xTaskGetTickCount();
	 for(;;)
  {
		ErrorMessage=CheckIng();
			
    osDelayUntil(&xLastWakeTime, SELFCHEK_PERIOD);
  }
}
	
void selfCheckTaskThreadCreate(osPriority taskPriority)
{
	osThreadDef(checkTask, SelfCheckTask, taskPriority, 0, 64);
  selfCheckTaskHandle = osThreadCreate(osThread(checkTask), NULL);
}
