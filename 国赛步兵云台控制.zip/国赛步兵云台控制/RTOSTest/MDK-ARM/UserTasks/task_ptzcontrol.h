#ifndef __PTZCONTROL_TASK_H
#define __PTZCONTROL_TASK_H

#include "stm32f4xx_hal.h"
#include "cmsis_os.h"
#include "bsp_can.h"
#include "bsp_ptz_control.h"
typedef struct
{
	  uint16_t Pitch_CurrentOut;
	  uint16_t Yaw_CurrentOut;
	
} SET_MSG_PTZ;

extern SET_MSG_PTZ St_Meg_Ptz;
void PtzcontrolTaskThreadCreate(osPriority taskPriority);

extern uint8_t sniper_flag;
void Ptz_Move(void);
void DaControlTaskThreadCreate(osPriority taskPriority);
#endif
