#ifndef __TASK_LED_H
#define __TASK_LED_H

void BlinkLedRed(void const *argument);
void BlinkLedBlue(void const *argument);
void Led_Task_Init(void);
#endif


