#ifndef ___IIC_H
#define ___IIC_H

#include "main.h"

//#include "define.h"
//#include "stm32f10x.h"

//typedef uint8 char;
//
//#define false    0
//#define	true     1

#define CLI()      __set_PRIMASK(1)  
#define SEI()      __set_PRIMASK(0)



#define true 1
#define false 0 
#define   uint8  uint8

#define TRUE  0
#define FALSE -1
/*
#define MPU6050_READRATE			1000	//6050��ȡƵ��
#define MPU6050_READTIME			0.001	//6050��ȡʱ����
#define EE_6050_ACC_X_OFFSET_ADDR	0
#define EE_6050_ACC_Y_OFFSET_ADDR	1
#define EE_6050_ACC_Z_OFFSET_ADDR	2
#define EE_6050_GYRO_X_OFFSET_ADDR	3
#define EE_6050_GYRO_Y_OFFSET_ADDR	4
#define EE_6050_GYRO_Z_OFFSET_ADDR	5
*/

/*====================================================================================================*/
/*====================================================================================================*/
uint8 i2cWriteBuffer(uint8 addr_, uint8 reg_, uint8 len_, uint8 *data);
uint8 i2cWrite(uint8 addr_, uint8 reg_, uint8 data);
uint8 i2cRead(uint8 addr_, uint8 reg_, uint8 len, uint8* buf);
void i2cInit(void);
uint16 i2cGetErrorCounter(void);
static void i2cUnstick(void);

int i2cwrite(uint8 addr, uint8 reg, uint8 len, uint8 * data);
int i2cread(uint8 addr, uint8 reg, uint8 len, uint8 *buf);
/*====================================================================================================*/
/*====================================================================================================*/
#endif
