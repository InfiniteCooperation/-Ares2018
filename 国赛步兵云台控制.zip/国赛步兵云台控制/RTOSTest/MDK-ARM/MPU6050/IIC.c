#include "IIC.h"


#define IIC_SCL_H()      GPIO_SetBits(GPIOB,GPIO_Pin_6)
#define IIC_SCL_L()      GPIO_ResetBits(GPIOB,GPIO_Pin_6)
#define IIC_SDA_H()      GPIO_SetBits(GPIOB,GPIO_Pin_7)
#define IIC_SDA_L()      GPIO_ResetBits(GPIOB,GPIO_Pin_7)
#define IIC_SDA_Read()   GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_7)

static void I2C_delay(void)
{
    volatile int i = 7;
    while (i)
        i--;
}

static uint8 I2C_Start(void)
{
    IIC_SDA_H();
    IIC_SCL_L();
    I2C_delay();
    if (!IIC_SDA_Read())
        return false;
    IIC_SDA_L();
    I2C_delay();
    if (IIC_SDA_Read())
        return false;
    IIC_SDA_L();
    I2C_delay();
    return true;
}

static void I2C_Stop(void)
{
    IIC_SCL_L();
    I2C_delay();
    IIC_SDA_L();
    I2C_delay();
    IIC_SCL_H();
    I2C_delay();
    IIC_SDA_H();
    I2C_delay();
}

static void I2C_Ack(void)
{
    IIC_SCL_L();
    I2C_delay();
    IIC_SDA_L();
    I2C_delay();
    IIC_SCL_H();
    I2C_delay();
    IIC_SCL_L();
    I2C_delay();
}

static void I2C_NoAck(void)
{
    IIC_SCL_L();
    I2C_delay();
    IIC_SDA_H();
    I2C_delay();
    IIC_SCL_H();
    I2C_delay();
    IIC_SCL_L();
    I2C_delay();
}

static uint8 I2C_WaitAck(void)
{
    IIC_SCL_L();
    I2C_delay();
    IIC_SDA_H();
    I2C_delay();
    IIC_SCL_H();
    I2C_delay();
    if (IIC_SDA_Read()) {
        IIC_SCL_L();
        return false;
    }
    IIC_SCL_L();
    return true;
}

static void I2C_SendByte(uint8 byte)
{
    uint8 i = 8;
    while (i--) {
        IIC_SCL_L();
        I2C_delay();
        if (byte & 0x80)
            IIC_SDA_H();
        else
            IIC_SDA_L();
        byte <<= 1;
        I2C_delay();
        IIC_SCL_H();
        I2C_delay();
    }
    IIC_SCL_L();
}

static uint8 I2C_ReceiveByte(void)
{
    uint8 i = 8;
    uint8 byte = 0;

    IIC_SDA_H();
    while (i--) {
        byte <<= 1;
        IIC_SCL_L();
        I2C_delay();
        IIC_SCL_H();
        I2C_delay();
        if (IIC_SDA_Read()) {
            byte |= 0x01;
        }
    }
    IIC_SCL_L();
    return byte;
}

void i2cInit(void)
{
	GPIO_InitTypeDef   gpio;
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB,ENABLE);
	gpio.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7;
	gpio.GPIO_Mode = GPIO_Mode_OUT;
	gpio.GPIO_OType = GPIO_OType_OD;
	gpio.GPIO_Speed = GPIO_Speed_100MHz; 
  GPIO_Init(GPIOB, &gpio);
	
	//HEAT_Configuration();
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB,ENABLE);
		
	gpio.GPIO_Pin = GPIO_Pin_4;	
	gpio.GPIO_Mode = GPIO_Mode_OUT;
	gpio.GPIO_OType = GPIO_OType_PP;
	gpio.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(GPIOB, &gpio);
  GPIO_ResetBits(GPIOB,GPIO_Pin_4);//0
}

uint8 i2cWriteBuffer(uint8 addr, uint8 reg, uint8 len, uint8 * data)
{
    int i;
    if (!I2C_Start())
        return false;
    I2C_SendByte(addr << 1 | I2C_Direction_Transmitter);
    if (!I2C_WaitAck()) {
        I2C_Stop();
        return false;
    }
    I2C_SendByte(reg);
    I2C_WaitAck();
    for (i = 0; i < len; i++) {
        I2C_SendByte(data[i]);
        if (!I2C_WaitAck()) {
            I2C_Stop();
            return false;
        }
    }
    I2C_Stop();
    return true;
}
/////////////////////////////////////////////////////////////////////////////////
int i2cwrite(uint8 addr, uint8 reg, uint8 len, uint8 * data)
{
	if(i2cWriteBuffer(addr,reg,len,data))
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
	//return FALSE;
}
int i2cread(uint8 addr, uint8 reg, uint8 len, uint8 *buf)
{
	if(i2cRead(addr,reg,len,buf))
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
	//return FALSE;
}
//////////////////////////////////////////////////////////////////////////////////
uint8 i2cWrite(uint8 addr, uint8 reg, uint8 data)
{
    if (!I2C_Start())
        return false;
    I2C_SendByte(addr << 1 | I2C_Direction_Transmitter);
    if (!I2C_WaitAck()) {
        I2C_Stop();
        return false;
    }
    I2C_SendByte(reg);
    I2C_WaitAck();
    I2C_SendByte(data);
    I2C_WaitAck();
    I2C_Stop();
    return true;
}

uint8 i2cRead(uint8 addr, uint8 reg, uint8 len, uint8 *buf)
{
    if (!I2C_Start())
        return false;
    I2C_SendByte(addr << 1 | I2C_Direction_Transmitter);
    if (!I2C_WaitAck()) {
        I2C_Stop();
        return false;
    }
    I2C_SendByte(reg);
    I2C_WaitAck();
    I2C_Start();
    I2C_SendByte(addr << 1 | I2C_Direction_Receiver);
    I2C_WaitAck();
    while (len) {
        *buf = I2C_ReceiveByte();
        if (len == 1)
            I2C_NoAck();
        else
            I2C_Ack();
        buf++;
        len--;
    }
    I2C_Stop();
    return true;
}

uint16 i2cGetErrorCounter(void)
{
    // TODO maybe fix this, but since this is test code, doesn't matter.
    return 0;
}
