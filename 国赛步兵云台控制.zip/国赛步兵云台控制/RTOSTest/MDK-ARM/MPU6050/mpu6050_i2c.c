#include "main.h"
#include "stm32f4xx.h"
#include "gpio.h"
#include "inv_mpu.h"
#include "inv_mpu_dmp_motion_driver.h"
#include "mpu6050_i2c.h"

void IIC_GPIO_Init(void)
{
	MX_GPIO_Init();
	IIC_SCL_H();
	IIC_SDA_H();
}
void IIC_Delay(unsigned int t)
{
    int i;
    for( i=0; i<t; i++)
    {
        int a = 6;//6
        while(a--);
    }
}




uint8_t dmp_set_init(void)
{
    static signed char gyro_orientation[9] =
    {-1, 0, 0,0,-1, 0,0, 0, 1};
	
    while(mpu_init())
	{
		//6050�ڲ���ʼ�����ɺ����˸
    }

    if(!mpu_set_sensors(INV_XYZ_GYRO | INV_XYZ_ACCEL))
    {}
    else
        return 1;
    if(!mpu_configure_fifo(INV_XYZ_GYRO | INV_XYZ_ACCEL))	   	  //mpu_configure_fifo
    {}
    else
        return 1;
    if(!mpu_set_sample_rate(DEFAULT_MPU_HZ))	   	  //mpu_set_sample_rate 100HZ
    {}
    else
        return 1;
    if(!dmp_load_motion_driver_firmware())   	  //dmp_load_motion_driver_firmvare
    {}
    else
        return 1;
    if(!dmp_set_orientation(inv_orientation_matrix_to_scalar(gyro_orientation))) 	  //dmp_set_orientation
    {}
    else
        return 1;
    if(!dmp_enable_feature(DMP_FEATURE_6X_LP_QUAT | DMP_FEATURE_TAP |
                           DMP_FEATURE_ANDROID_ORIENT | DMP_FEATURE_SEND_RAW_ACCEL | DMP_FEATURE_SEND_CAL_GYRO |
                           DMP_FEATURE_GYRO_CAL))		   	  //dmp_enable_feature
    {}
    else
        return 1;
    if(!dmp_set_fifo_rate(DEFAULT_MPU_HZ))   	  //dmp_set_fifo_rate
    {}
    else
        return 1;
    run_self_test();
    if(!mpu_set_dmp_state(1))
    {}
    else
        return 1;

    return 0;
}


void IIC_Start(void)
{
    IIC_SDA_Out();
    IIC_SDA_H();
    IIC_SCL_H();
    IIC_Delay(1);
    IIC_SDA_L();
    IIC_Delay(1);
    IIC_SCL_L();
}

void IIC_Stop(void)
{
    IIC_SDA_Out();
    IIC_SCL_L();
    IIC_SDA_L();
    IIC_Delay(1);
    IIC_SCL_H();
    IIC_SDA_H();
    IIC_Delay(1);
}

void IIC_Ack(uint8_t re)
{
    IIC_SDA_Out();
    if(re)
    IIC_SDA_H();
    else
    IIC_SDA_L();
    IIC_SCL_H();
    IIC_Delay(1);
    IIC_SCL_L();
    IIC_Delay(1);
}

int IIC_WaitAck(void)
{
    uint16_t Out_Time=1000;

    IIC_SDA_H();
    IIC_SDA_In();
    IIC_Delay(1);
    IIC_SCL_H();
    IIC_Delay(1);
    while(IIC_SDA_Read())
    {
        if(--Out_Time)
        {
            IIC_Stop();
            return NO_ACK;
        }
    }
    IIC_SCL_L();
    return 0;
}
//#include "led.h"

void IIC_WriteBit(uint8_t Temp)
{
    uint8_t i;
    IIC_SDA_Out();
    IIC_SCL_L();
	
    for(i=0; i<8; i++)
    {
        if(Temp&0x80)
        {
            IIC_SDA_H();
        }
        else
        {
            IIC_SDA_L();
        }
        Temp<<=1;
        IIC_Delay(1);
        IIC_SCL_H();
        IIC_Delay(1);
        IIC_SCL_L();
    }
}

uint8_t IIC_ReadBit(void)
{
    uint8_t i,Temp=0;
    IIC_SDA_In();
    for(i=0; i<8; i++)
    {
        IIC_SCL_L();
        IIC_Delay(1);
        IIC_SCL_H();
        Temp<<=1;
        if(IIC_SDA_Read())
            Temp++;
        IIC_Delay(1);
    }
    IIC_SCL_L();
    return Temp;
}
//д���ݣ��ɹ�����0��ʧ�ܷ���WR_NO_ACK
int IIC_WriteData(uint8_t dev_addr,uint8_t reg_addr,uint8_t len,uint8_t *data)
{
    int i;
    IIC_Start();
	
    IIC_WriteBit(dev_addr);
	
	if(IIC_WaitAck())
	{
		return WR_NO_ACK;
	}

	IIC_WriteBit(reg_addr);
	if(IIC_WaitAck())
	{
		return WR_NO_ACK;
	}

	for (i = 0; i < len; i++)
	{
		IIC_WriteBit(data[i]);
		if(IIC_WaitAck())
		{
			return WR_NO_ACK;
		}
	}
    IIC_Stop();
    return 0;
}


//�����ݣ��ɹ�����0��ʧ�ܷ���0xff
int IIC_ReadData(uint8_t dev_addr,uint8_t reg_addr,uint8_t count,uint8_t *pdata)
{
    uint8_t i;
    IIC_Start();
    IIC_WriteBit(dev_addr);
    if(IIC_WaitAck())
    {
        return RE_NO_ACK;
    }

    IIC_WriteBit(reg_addr);
    if(IIC_WaitAck())
    {
        return RE_NO_ACK;
    }

    IIC_Start();
    IIC_WriteBit(dev_addr+1);
    if(IIC_WaitAck())
    {
        return RE_NO_ACK;
    }

    for(i=0; i<(count-1); i++)
    {
        *pdata=IIC_ReadBit();
        IIC_Ack(0);
        pdata++;
    }

    *pdata=IIC_ReadBit();
    IIC_Ack(1);

    IIC_Stop();

    return 0;
}

//IICдһ���ֽ� 
//reg:�Ĵ�����ַ
//data:����
//����ֵ:0,����
//    ����,�������

uint8_t MPU_Write_Byte(uint8_t reg,uint8_t data)
{
    IIC_Start(); 
	IIC_WriteBit((MPU_ADDR<<1)|0);//����������ַ+д����	
	if(IIC_WaitAck())	//�ȴ�Ӧ��
	{
		IIC_Stop();		 
		return WR_NO_ACK;		
	}
    IIC_WriteBit(reg);	//д�Ĵ�����ַ
    IIC_WaitAck();		//�ȴ�Ӧ�� 
	IIC_WriteBit(data);//��������
	if(IIC_WaitAck())	//�ȴ�ACK
	{
		IIC_Stop();	 
		return WR_NO_ACK;		 
	}
    IIC_Stop();	 
	return 0;
}

//IIC��һ���ֽ� 
//reg:�Ĵ�����ַ 
//����ֵ:����������
uint8_t MPU_Read_Byte(uint8_t reg)
{
	uint8_t res;
    IIC_Start(); 
	IIC_WriteBit((MPU_ADDR<<1)|0);//����������ַ+д����	
	IIC_WaitAck();		//�ȴ�Ӧ�� 
    IIC_WriteBit(reg);	//д�Ĵ�����ַ
    IIC_WaitAck();		//�ȴ�Ӧ��
    IIC_Start();
	IIC_WriteBit((MPU_ADDR<<1)|1);//����������ַ+������	
    IIC_WaitAck();		//�ȴ�Ӧ�� 
	res=IIC_ReadBit();//��ȡ����,����nACK 
	IIC_Ack(1);
    IIC_Stop();			//����һ��ֹͣ���� 
	return res;		
}
